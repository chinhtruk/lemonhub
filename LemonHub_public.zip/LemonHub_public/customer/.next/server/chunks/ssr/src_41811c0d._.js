module.exports = {

"[project]/src/utils/image.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "getFullImageUrl": (()=>getFullImageUrl)
});
const getFullImageUrl = (imagePath)=>{
    // Debug info
    console.log('Original image path:', imagePath);
    // Check for empty or undefined paths
    if (!imagePath) {
        console.log('Image path is empty, using placeholder');
        return '/images/product-placeholder.svg';
    }
    // If the image URL is already absolute, return it as is
    if (imagePath.startsWith('http')) {
        console.log('Image path is already absolute');
        return imagePath;
    }
    // For server-side paths that start with /uploads
    if (imagePath.startsWith('/uploads')) {
        const serverUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001';
        const fullUrl = `${serverUrl}${imagePath}`;
        console.log('Server image path, resolved to:', fullUrl);
        return fullUrl;
    }
    // Hardcode the base URL for testing if environment variable is not set
    const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001';
    console.log('Using base URL:', baseUrl);
    // Remove trailing slash from base URL if it exists
    const cleanBaseUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
    // Add leading slash to image path if it doesn't exist
    const cleanImagePath = imagePath.startsWith('/') ? imagePath : `/${imagePath}`;
    // Combine base URL and image path
    const fullUrl = `${cleanBaseUrl}${cleanImagePath}`;
    console.log('Resolved full URL:', fullUrl);
    return fullUrl;
};
}}),
"[project]/src/services/product.service.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "createProduct": (()=>createProduct),
    "createProductReview": (()=>createProductReview),
    "deleteProduct": (()=>deleteProduct),
    "getAllProducts": (()=>getAllProducts),
    "getBanners": (()=>getBanners),
    "getBestSellingProducts": (()=>getBestSellingProducts),
    "getFeaturedProducts": (()=>getFeaturedProducts),
    "getNewProducts": (()=>getNewProducts),
    "getNewestProducts": (()=>getNewestProducts),
    "getProductById": (()=>getProductById),
    "getProductBySlug": (()=>getProductBySlug),
    "getProductReviews": (()=>getProductReviews),
    "getProductsByCategory": (()=>getProductsByCategory),
    "getRelatedProducts": (()=>getRelatedProducts),
    "getTopRatedProducts": (()=>getTopRatedProducts),
    "searchProducts": (()=>searchProducts),
    "updateProduct": (()=>updateProduct),
    "updateStatus": (()=>updateStatus),
    "updateStock": (()=>updateStock)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/api.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/image.ts [app-ssr] (ecmascript)");
;
;
// Hàm chuyển đổi dữ liệu sản phẩm từ API sang định dạng frontend
const transformProduct = (product)=>{
    // Kiểm tra xem product có tồn tại không
    if (!product) return null;
    // Đảm bảo đường dẫn ảnh đầy đủ
    const mainImage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFullImageUrl"])(product.image);
    // Xử lý mảng ảnh phụ (chỉ lấy những ảnh phụ khác với ảnh chính)
    let additionalImages = [];
    if (Array.isArray(product.images) && product.images.length > 0) {
        additionalImages = product.images.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFullImageUrl"]).filter((img)=>img && img !== mainImage); // Loại bỏ ảnh trùng với ảnh chính và ảnh null
    }
    // Tạo mảng đầy đủ các ảnh, với ảnh chính ở đầu tiên
    const allImages = [
        mainImage,
        ...additionalImages
    ];
    // Chuyển đổi specifications từ Map sang mảng các đối tượng
    let specifications = [];
    if (product.specifications) {
        if (product.specifications instanceof Map) {
            // Nếu specifications là Map
            for (const [key, value] of product.specifications.entries()){
                specifications.push({
                    name: key,
                    value: value
                });
            }
        } else if (typeof product.specifications === 'object') {
            // Nếu specifications là object thông thường
            specifications = Object.entries(product.specifications).map(([key, value])=>({
                    name: key,
                    value: value
                }));
        }
    }
    return {
        id: product._id || product.id || '',
        name: product.name || 'Sản phẩm',
        slug: product.slug || '',
        price: product.price || 0,
        originalPrice: product.salePrice || product.originalPrice || product.price || 0,
        image: mainImage,
        images: allImages,
        description: product.description || '',
        brand: product.brand || '',
        category: product.category ? {
            id: product.category._id || product.category.id || '',
            name: product.category.name || ''
        } : null,
        countInStock: product.countInStock || 0,
        stock: product.countInStock || product.stock || 0,
        rating: product.rating || 0,
        numReviews: product.numReviews || 0,
        isFeatured: Boolean(product.isFeatured),
        specifications: specifications // Thêm specifications vào dữ liệu trả về
    };
};
// Dữ liệu mẫu cho sản phẩm
const FALLBACK_PRODUCTS = [
    {
        id: 'fallback1',
        name: 'Laptop Gaming Asus',
        price: 25990000,
        originalPrice: 29990000,
        image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
    },
    {
        id: 'fallback2',
        name: 'Samsung Galaxy S23 Ultra',
        price: 18990000,
        originalPrice: 21990000,
        image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
    },
    {
        id: 'fallback3',
        name: 'Apple iPad Pro',
        price: 29990000,
        originalPrice: 35990000,
        image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
    }
];
// Dữ liệu mẫu cho banner
const FALLBACK_BANNERS = [
    {
        id: 1,
        title: "Trải nghiệm công nghệ tốt nhất",
        subtitle: "Các sản phẩm chất lượng cao với mức giá hợp lý",
        image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1500&q=80"
    },
    {
        id: 2,
        title: "Thiết bị thông minh cho cuộc sống",
        subtitle: "Khám phá bộ sưu tập thiết bị mới nhất",
        image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1500&q=80"
    }
];
// Hàm chuyển đổi mảng sản phẩm
const transformProducts = (data)=>{
    try {
        // First check if data is null or undefined
        if (!data) {
            console.warn('Empty data passed to transformProducts');
            return [];
        }
        // Check if data is already an array of products
        if (Array.isArray(data)) {
            console.log('Data is array, mapping directly:', data.length, 'items');
            return data.map(transformProduct).filter(Boolean);
        }
        // Check if data has a 'products' property that is an array
        if (data.products && Array.isArray(data.products)) {
            console.log('Data has products array:', data.products.length, 'items');
            return data.products.map(transformProduct).filter(Boolean);
        }
        console.warn('Invalid products data structure:', data);
        return [];
    } catch (error) {
        console.error('Error transforming products:', error);
        return [];
    }
};
const getAllProducts = async (params)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('/products', {
            params
        });
        return {
            ...data,
            products: transformProducts(data)
        };
    } catch (error) {
        console.error('Error in getAllProducts:', error);
        return {
            products: FALLBACK_PRODUCTS,
            page: 1,
            pages: 1,
            total: FALLBACK_PRODUCTS.length
        };
    }
};
const getProductById = async (id)=>{
    try {
        console.log('Fetching product with ID:', id);
        // Fetch the product details
        const { data: product } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/${id}`);
        console.log('Raw product data:', product);
        const transformedProduct = transformProduct(product);
        console.log('Transformed product:', transformedProduct);
        return transformedProduct;
    } catch (error) {
        console.error('Error in getProductById:', error);
        // Fallback to a dummy product if real data couldn't be fetched
        return FALLBACK_PRODUCTS.find((p)=>p.id === id) || FALLBACK_PRODUCTS[0];
    }
};
const getProductBySlug = async (slug)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/slug/${slug}`);
        return transformProduct(data);
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch product by slug';
    }
};
const searchProducts = async (keyword, page = 1, limit = 10)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('/products', {
            params: {
                keyword,
                page,
                limit
            }
        });
        return {
            ...data,
            products: transformProducts(data)
        };
    } catch (error) {
        throw error.response?.data?.message || 'Could not search products';
    }
};
const getProductsByCategory = async (categoryId, page = 1, limit = 12, sort = '')=>{
    try {
        console.log('Fetching products for category:', categoryId);
        // Convert frontend sort values to API sort parameters
        let sortParam = '';
        switch(sort){
            case 'newest':
                sortParam = '-createdAt';
                break;
            case 'price-asc':
                sortParam = 'price';
                break;
            case 'price-desc':
                sortParam = '-price';
                break;
            case 'name-asc':
                sortParam = 'name';
                break;
            case 'name-desc':
                sortParam = '-name';
                break;
            case 'popular':
                sortParam = '-numSales';
                break;
            case 'rating':
                sortParam = '-rating';
                break;
            default:
                sortParam = '-createdAt';
        }
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/category/${categoryId}`, {
            params: {
                page,
                limit,
                sort: sortParam
            }
        });
        // Transform the response data
        const transformedData = {
            products: transformProducts(data),
            page: data.page,
            pages: data.pages,
            total: data.total,
            category: data.category
        };
        console.log('Transformed category products:', transformedData);
        return transformedData;
    } catch (error) {
        console.error('Error in getProductsByCategory:', error);
        throw error.response?.data?.message || 'Could not fetch products by category';
    }
};
const createProductReview = async (productId, review)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post(`/products/${productId}/reviews`, review);
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Could not create product review';
    }
};
const getFeaturedProducts = async (limit = 8)=>{
    try {
        console.log('Fetching featured products with limit:', limit);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/featured`, {
            params: {
                limit
            }
        });
        console.log('Received featured products data:', data);
        // Kiểm tra dữ liệu trước khi chuyển đổi
        if (!data) {
            console.warn('Empty data received from featured products API');
            return FALLBACK_PRODUCTS;
        }
        const transformed = transformProducts(data);
        console.log('Transformed featured products:', transformed);
        // Nếu không có sản phẩm nổi bật, trả về sản phẩm mẫu
        if (!transformed || transformed.length === 0) {
            console.log('No featured products found, using fallbacks');
            return FALLBACK_PRODUCTS;
        }
        return transformed;
    } catch (error) {
        console.error('Error in getFeaturedProducts:', error);
        // Return fallback products instead of throwing
        return FALLBACK_PRODUCTS;
    }
};
const getNewProducts = async (limit = 8)=>{
    try {
        console.log('Fetching newest products with limit:', limit);
        // Updated to use the correct endpoint
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/newest`, {
            params: {
                limit
            }
        });
        // Extra check to ensure data is valid
        if (!data || !Array.isArray(data)) {
            console.error('Invalid data received for newest products:', data);
            return [];
        }
        console.log('Received newest products data:', data.length, 'items');
        // Process each product to ensure valid image URLs
        const productsWithImages = data.map((product)=>{
            if (!product.image || product.image === '') {
                console.warn('Product without image:', product._id);
                // Set a default image
                product.image = '/images/product-placeholder.svg';
            }
            return product;
        });
        const transformed = transformProducts(productsWithImages);
        console.log('Transformed newest products:', transformed.length, 'items');
        return transformed;
    } catch (error) {
        console.error('Error in getNewProducts:', error);
        // Return empty array instead of throwing to prevent UI errors
        return [];
    }
};
const getTopRatedProducts = async (limit = 3)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/top`, {
            params: {
                limit
            }
        });
        return transformProducts(data);
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch top rated products';
    }
};
const getRelatedProducts = async (productId, limit = 4)=>{
    try {
        console.log('Fetching related products for ID:', productId);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/${productId}/related`, {
            params: {
                limit
            }
        });
        // API trả về { products: [...] }
        const productsArray = data.products || data;
        // Check if data exists and is an array
        if (!productsArray || !Array.isArray(productsArray)) {
            console.warn('Invalid data structure returned for related products:', data);
            return [];
        }
        // Ensure all products have valid images
        const productsWithImages = productsArray.map((product)=>{
            if (!product.image || product.image === '') {
                console.warn('Related product without image:', product._id);
                product.image = '/images/product-placeholder.svg';
            }
            return product;
        });
        const transformed = productsArray.map(transformProduct).filter(Boolean);
        console.log('Successfully fetched related products:', transformed.length, 'items');
        return transformed;
    } catch (error) {
        console.error('Error in getRelatedProducts:', error);
        // Return empty array instead of throwing to prevent UI errors
        return [];
    }
};
const getProductReviews = async (productId, page = 1, limit = 10)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/${productId}/reviews`, {
            params: {
                page,
                limit
            }
        });
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch product reviews';
    }
};
const getBestSellingProducts = async (limit = 8)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/best-selling`, {
            params: {
                limit
            }
        });
        return transformProducts(data);
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch best selling products';
    }
};
const getBanners = async ()=>{
    try {
        console.log('Fetching banners');
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('/banners');
        console.log('Received banners data:', data);
        // Kiểm tra dữ liệu trước khi xử lý
        if (!data || !Array.isArray(data) || data.length === 0) {
            console.warn('No banners data received or invalid format');
            return FALLBACK_BANNERS;
        }
        // Chuyển đổi _id thành id cho banners và đảm bảo đường dẫn ảnh đầy đủ
        const transformed = data.map((banner)=>{
            if (!banner) return null;
            // Process image path using our utility
            const imagePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFullImageUrl"])(banner.image);
            return {
                id: banner._id || banner.id || Math.random().toString(36).substr(2, 9),
                title: banner.title || 'Công nghệ mới',
                subtitle: banner.subtitle || 'Khám phá các sản phẩm mới nhất',
                image: imagePath || FALLBACK_BANNERS[0].image,
                link: banner.link || '',
                isActive: banner.isActive || true
            };
        }).filter(Boolean);
        if (transformed.length === 0) {
            console.warn('No valid banners after transformation');
            return FALLBACK_BANNERS;
        }
        console.log('Transformed banners:', transformed);
        return transformed;
    } catch (error) {
        console.error('Error in getBanners:', error);
        return FALLBACK_BANNERS;
    }
};
const createProduct = async (productData)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/products', productData);
    return response.data;
};
const updateProduct = async (id, productData)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].put(`/products/${id}`, productData);
    return response.data;
};
const deleteProduct = async (id)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].delete(`/products/${id}`);
    return response.data;
};
const updateStock = async (id, stock)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].patch(`/products/${id}/stock`, {
        stock
    });
    return response.data;
};
const updateStatus = async (id, isActive)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].patch(`/products/${id}/status`, {
        isActive
    });
    return response.data;
};
const getNewestProducts = async (limit = 8)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/products/newest`, {
            params: {
                limit
            }
        });
        return transformProducts(data);
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch newest products';
    }
};
}}),
"[project]/src/services/category.service.js [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "createCategory": (()=>createCategory),
    "deleteCategory": (()=>deleteCategory),
    "getAllCategories": (()=>getAllCategories),
    "getCategoryById": (()=>getCategoryById),
    "getCategoryBySlug": (()=>getCategoryBySlug),
    "getFeaturedCategories": (()=>getFeaturedCategories),
    "getParentCategories": (()=>getParentCategories),
    "updateCategory": (()=>updateCategory),
    "updateOrder": (()=>updateOrder),
    "updateStatus": (()=>updateStatus)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/api.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/image.ts [app-ssr] (ecmascript)");
;
;
// Dữ liệu mẫu cho danh mục khi API không trả về kết quả
const FALLBACK_CATEGORIES = [
    {
        id: 'cat1',
        _id: 'cat1',
        name: 'Điện thoại di động',
        slug: 'dien-thoai-di-dong',
        description: 'Các loại điện thoại di động mới nhất',
        icon: '📱',
        image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-4.0.3',
        isFeatured: true,
        order: 1,
        parentCategory: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    },
    {
        id: 'cat2',
        _id: 'cat2',
        name: 'Laptop & Máy tính',
        slug: 'laptop-may-tinh',
        description: 'Laptop và máy tính để bàn các loại',
        icon: '💻',
        image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3',
        isFeatured: true,
        order: 2,
        parentCategory: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    },
    {
        id: 'cat3',
        _id: 'cat3',
        name: 'Thiết bị thông minh',
        slug: 'thiet-bi-thong-minh',
        description: 'Các thiết bị thông minh và đồ điện tử',
        icon: '⌚',
        image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?ixlib=rb-4.0.3',
        isFeatured: true,
        order: 3,
        parentCategory: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    }
];
// Transform category data from API response
const transformCategory = (category)=>{
    if (!category) return null;
    // Use the getFullImageUrl utility to ensure proper image URL
    const imageUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFullImageUrl"])(category.image);
    return {
        id: category._id || category.id || '',
        _id: category._id || category.id || '',
        name: category.name || 'Danh mục không tên',
        slug: category.slug || '',
        description: category.description || '',
        icon: category.icon || '📦',
        image: imageUrl,
        isFeatured: Boolean(category.isFeatured),
        order: category.order || 0,
        parentCategory: category.parentCategory || null,
        createdAt: category.createdAt || new Date().toISOString(),
        updatedAt: category.updatedAt || new Date().toISOString()
    };
};
const getAllCategories = async ()=>{
    try {
        console.log('Fetching all categories');
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('/categories');
        if (response.data && Array.isArray(response.data)) {
            console.log(`Received ${response.data.length} categories from API`);
            return response.data.map(transformCategory).filter(Boolean);
        }
        console.warn('Invalid category data received from API');
        return FALLBACK_CATEGORIES; // Return fallback data if no valid data
    } catch (error) {
        console.error('Error fetching categories:', error);
        return FALLBACK_CATEGORIES; // Return fallback data on error
    }
};
const getFeaturedCategories = async ()=>{
    try {
        console.log('Fetching featured categories');
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('/categories/featured');
        if (response.data && Array.isArray(response.data)) {
            console.log(`Received ${response.data.length} featured categories from API`);
            return response.data.map(transformCategory).filter(Boolean);
        }
        console.warn('Invalid featured category data received from API');
        return FALLBACK_CATEGORIES.filter((cat)=>cat.isFeatured);
    } catch (error) {
        console.error('Error fetching featured categories:', error);
        return FALLBACK_CATEGORIES.filter((cat)=>cat.isFeatured);
    }
};
const getCategoryById = async (id)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/categories/${id}`);
        if (response.data) {
            return transformCategory(response.data);
        }
        return FALLBACK_CATEGORIES.find((cat)=>cat.id === id) || null;
    } catch (error) {
        console.error('Error fetching category by id:', error);
        return FALLBACK_CATEGORIES.find((cat)=>cat.id === id) || null;
    }
};
const getCategoryBySlug = async (slug)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get(`/categories/slug/${slug}`);
        if (response.data) {
            return transformCategory(response.data);
        }
        return FALLBACK_CATEGORIES.find((cat)=>cat.slug === slug) || null;
    } catch (error) {
        console.error('Error fetching category by slug:', error);
        return FALLBACK_CATEGORIES.find((cat)=>cat.slug === slug) || null;
    }
};
const getParentCategories = async ()=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].get('/categories/parents');
        if (response.data && Array.isArray(response.data)) {
            return response.data.map(transformCategory).filter(Boolean);
        }
        return FALLBACK_CATEGORIES.filter((cat)=>cat.parentCategory === null);
    } catch (error) {
        console.error('Error fetching parent categories:', error);
        return FALLBACK_CATEGORIES.filter((cat)=>cat.parentCategory === null);
    }
};
const createCategory = async (categoryData)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].post('/categories', categoryData);
        return response.data;
    } catch (error) {
        console.error('Error creating category:', error);
        throw error;
    }
};
const updateCategory = async (id, categoryData)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].put(`/categories/${id}`, categoryData);
        return response.data;
    } catch (error) {
        console.error('Error updating category:', error);
        throw error;
    }
};
const deleteCategory = async (id)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].delete(`/categories/${id}`);
        return response.data;
    } catch (error) {
        console.error('Error deleting category:', error);
        throw error;
    }
};
const updateOrder = async (id, order)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].patch(`/categories/${id}/order`, {
            order
        });
        return response.data;
    } catch (error) {
        console.error('Error updating category order:', error);
        throw error;
    }
};
const updateStatus = async (id, isActive)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].patch(`/categories/${id}/status`, {
            isActive
        });
        return response.data;
    } catch (error) {
        console.error('Error updating category status:', error);
        throw error;
    }
};
}}),
"[project]/src/app/page.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Home)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/styled-jsx/style.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$product$2e$service$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/product.service.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$category$2e$service$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/category.service.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
function Home() {
    const [currentBanner, setCurrentBanner] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    // State để lưu trữ dữ liệu từ API
    const [banners, setBanners] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [featuredProducts, setFeaturedProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [categories, setCategories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [featuredCategories, setFeaturedCategories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    // Use this for fallback banners if needed
    const fallbackBanners = [
        {
            id: 1,
            title: "Trải nghiệm công nghệ tốt nhất",
            subtitle: "Các sản phẩm chất lượng cao với mức giá hợp lý",
            image: "/images/placeholder-banner.svg"
        },
        {
            id: 2,
            title: "Thiết bị thông minh cho cuộc sống",
            subtitle: "Khám phá bộ sưu tập thiết bị mới nhất",
            image: "/images/placeholder-banner.svg"
        }
    ];
    // Hàm chuyển đổi dữ liệu từ API sang kiểu Product
    const transformApiProduct = (apiProduct)=>{
        if (!apiProduct) return null;
        // Đảm bảo luôn có đường dẫn hình ảnh hợp lệ
        let imageUrl = apiProduct.image || '';
        if (!imageUrl.startsWith('http')) {
            const baseUrl = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5001';
            imageUrl = imageUrl.startsWith('/') ? `${baseUrl}${imageUrl}` : `${baseUrl}/${imageUrl}`;
        }
        return {
            id: apiProduct._id || apiProduct.id || '',
            name: apiProduct.name || 'Sản phẩm không tên',
            price: Number(apiProduct.price) || 0,
            originalPrice: apiProduct.originalPrice ? Number(apiProduct.originalPrice) : undefined,
            discount: apiProduct.discount ? Number(apiProduct.discount) : undefined,
            image: imageUrl,
            images: apiProduct.images || [],
            description: apiProduct.description,
            brand: apiProduct.brand,
            category: apiProduct.category ? {
                id: apiProduct.category._id || apiProduct.category.id || '',
                name: apiProduct.category.name || ''
            } : undefined,
            countInStock: apiProduct.countInStock ? Number(apiProduct.countInStock) : undefined,
            stock: apiProduct.stock ? Number(apiProduct.stock) : undefined,
            rating: apiProduct.rating ? Number(apiProduct.rating) : undefined,
            numReviews: apiProduct.numReviews ? Number(apiProduct.numReviews) : undefined,
            isFeatured: apiProduct.isFeatured,
            slug: apiProduct.slug
        };
    };
    function transformApiCategory(apiCategory) {
        return {
            _id: apiCategory._id || apiCategory.id,
            id: apiCategory.id || apiCategory._id,
            name: apiCategory.name,
            slug: apiCategory.slug,
            description: apiCategory.description,
            icon: apiCategory.icon,
            image: apiCategory.image,
            isFeatured: apiCategory.isFeatured,
            order: apiCategory.order,
            parentCategory: apiCategory.parentCategory,
            createdAt: apiCategory.createdAt,
            updatedAt: apiCategory.updatedAt
        };
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchData = async ()=>{
            try {
                setIsLoading(true);
                setError('');
                // Categories
                const categoriesData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$category$2e$service$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getAllCategories"])();
                if (Array.isArray(categoriesData)) {
                    setCategories(categoriesData.map((cat)=>({
                            ...cat,
                            _id: cat.id || ''
                        })));
                }
                // Featured Categories
                const featuredCategoriesData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$category$2e$service$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFeaturedCategories"])();
                if (Array.isArray(featuredCategoriesData)) {
                    setFeaturedCategories(featuredCategoriesData.map((cat)=>({
                            ...cat,
                            _id: cat.id || ''
                        })));
                }
                // Banners and Featured Products
                console.log('Fetching banners and featured products...');
                try {
                    const bannersData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$product$2e$service$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getBanners"])();
                    console.log('Received banners:', bannersData);
                    // Set banners - always use fallback if empty
                    if (bannersData && Array.isArray(bannersData) && bannersData.length > 0) {
                        setBanners(bannersData.filter((banner)=>banner !== null));
                    } else {
                        console.log('Using fallback banners');
                        setBanners(fallbackBanners);
                    }
                } catch (err) {
                    console.error('Banner fetch error:', err);
                    setBanners(fallbackBanners);
                }
                // Tạo sản phẩm nổi bật giả nếu API không trả về dữ liệu
                const fallbackProducts = [
                    {
                        id: 'fallback1',
                        name: 'Laptop Gaming Asus',
                        price: 25990000,
                        originalPrice: 29990000,
                        image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
                    },
                    {
                        id: 'fallback2',
                        name: 'Samsung Galaxy S23 Ultra',
                        price: 18990000,
                        originalPrice: 21990000,
                        image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
                    },
                    {
                        id: 'fallback3',
                        name: 'Apple iPad Pro',
                        price: 29990000,
                        originalPrice: 35990000,
                        image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
                    }
                ];
                try {
                    const featuredProductsData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$product$2e$service$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getFeaturedProducts"])();
                    console.log('Received featured products data:', featuredProductsData);
                    // Set featured products
                    if (featuredProductsData && Array.isArray(featuredProductsData) && featuredProductsData.length > 0) {
                        const transformedProducts = featuredProductsData.map((p)=>transformApiProduct(p)).filter((p)=>p !== null).slice(0, 16);
                        if (transformedProducts.length > 0) {
                            setFeaturedProducts(transformedProducts);
                        } else {
                            console.log('Using fallback products - transformed list was empty');
                            setFeaturedProducts(fallbackProducts);
                        }
                    } else {
                        console.log('Using fallback products - API returned empty');
                        setFeaturedProducts(fallbackProducts);
                    }
                } catch (err) {
                    console.error('Featured products fetch error:', err);
                    setFeaturedProducts(fallbackProducts);
                }
            } catch (error) {
                console.error('Error fetching data:', error);
                setError('Không thể tải dữ liệu. Vui lòng thử lại sau.');
                // Set fallback data
                setBanners(fallbackBanners);
                setFeaturedProducts([
                    {
                        id: 'fallback1',
                        name: 'Laptop Gaming Asus',
                        price: 25990000,
                        originalPrice: 29990000,
                        image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
                    },
                    {
                        id: 'fallback2',
                        name: 'Samsung Galaxy S23 Ultra',
                        price: 18990000,
                        originalPrice: 21990000,
                        image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
                    },
                    {
                        id: 'fallback3',
                        name: 'Apple iPad Pro',
                        price: 29990000,
                        originalPrice: 35990000,
                        image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
                    }
                ]);
            } finally{
                setIsLoading(false);
            }
        };
        fetchData();
    }, []);
    // Auto slide banners
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (banners.length === 0) return;
        const timer = setInterval(()=>{
            setCurrentBanner((prev)=>(prev + 1) % banners.length);
        }, 5000);
        return ()=>clearInterval(timer);
    }, [
        banners.length
    ]);
    const formatPrice = (price)=>{
        return new Intl.NumberFormat('vi-VN', {
            style: 'currency',
            currency: 'VND'
        }).format(price);
    };
    // Format số 2 chữ số (thêm số 0 phía trước nếu cần)
    const formatTwoDigits = (num)=>{
        return num.toString().padStart(2, '0');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gray-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full overflow-hidden",
                children: isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative aspect-[21/9] w-full bg-gray-800 animate-pulse"
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 296,
                    columnNumber: 11
                }, this) : banners.length === 0 ? // Fallback banner if no banners are loaded
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative aspect-[21/9] w-full bg-gray-800 flex items-center justify-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-white text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-4xl font-bold mb-4",
                                children: "LemonHub"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 301,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xl",
                                children: "Địa chỉ mua sắm công nghệ uy tín"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 302,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/page.tsx",
                        lineNumber: 300,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 299,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "overflow-hidden",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex transition-transform duration-500 ease-in-out",
                                style: {
                                    transform: `translateX(-${currentBanner * 100}%)`
                                },
                                children: banners.map((banner, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "min-w-full",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative aspect-[21/9] w-full overflow-hidden",
                                            children: banner.link ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                href: banner.link,
                                                className: "block w-full h-full",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    src: banner.image,
                                                    alt: banner.title,
                                                    fill: true,
                                                    priority: index === 0,
                                                    sizes: "100vw",
                                                    className: "object-cover",
                                                    onError: (e)=>{
                                                        console.error('Failed to load banner image:', banner.image);
                                                        // Fallback to a default image on error
                                                        e.currentTarget.src = '/images/placeholder-banner.svg';
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 317,
                                                    columnNumber: 27
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 316,
                                                columnNumber: 25
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                src: banner.image,
                                                alt: banner.title,
                                                fill: true,
                                                priority: index === 0,
                                                sizes: "100vw",
                                                className: "object-cover",
                                                onError: (e)=>{
                                                    console.error('Failed to load banner image:', banner.image);
                                                    // Fallback to a default image on error
                                                    e.currentTarget.src = '/images/placeholder-banner.svg';
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 332,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 314,
                                            columnNumber: 21
                                        }, this)
                                    }, banner.id, false, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 313,
                                        columnNumber: 19
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 308,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 307,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute bottom-8 md:bottom-12 left-1/2 transform -translate-x-1/2 flex space-x-3 md:space-x-4 z-30",
                            children: banners.map((_, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>setCurrentBanner(index),
                                    "aria-label": `Chuyển đến banner ${index + 1}`,
                                    className: `w-2 md:w-3 h-2 md:h-3 rounded-full transition-all duration-500 transform hover:scale-125 ${index === currentBanner ? 'bg-yellow-500 w-6 md:w-8' : 'bg-white/60 hover:bg-white'}`
                                }, `nav-${index}`, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 354,
                                    columnNumber: 13
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 352,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setCurrentBanner((prev)=>(prev - 1 + banners.length) % banners.length),
                            "aria-label": "Banner trước",
                            className: "absolute left-4 md:left-8 top-1/2 transform -translate-y-1/2 bg-black/20 hover:bg-black/40 text-white p-3 md:p-4 rounded-full transition-all duration-300 backdrop-blur-md hover:scale-110 z-30",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowRight"], {
                                className: "w-5 h-5 md:w-6 md:h-6 transform rotate-180"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 372,
                                columnNumber: 11
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 367,
                            columnNumber: 9
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setCurrentBanner((prev)=>(prev + 1) % banners.length),
                            "aria-label": "Banner tiếp theo",
                            className: "absolute right-4 md:right-8 top-1/2 transform -translate-y-1/2 bg-black/20 hover:bg-black/40 text-white p-3 md:p-4 rounded-full transition-all duration-300 backdrop-blur-md hover:scale-110 z-30",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowRight"], {
                                className: "w-5 h-5 md:w-6 md:h-6"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 379,
                                columnNumber: 11
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 374,
                            columnNumber: 9
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 306,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 294,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-16 md:py-24 bg-white scroll-mt-16",
                id: "featured",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center mb-8 md:mb-16",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-3xl md:text-4xl font-bold text-gray-900 mb-6",
                                    children: "Sản phẩm nổi bật"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 389,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex justify-center space-x-4 mt-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>{
                                                const container = document.getElementById('featured-products-container');
                                                if (container) {
                                                    container.scrollBy({
                                                        left: -300,
                                                        behavior: 'smooth'
                                                    });
                                                }
                                            },
                                            "aria-label": "Xem sản phẩm trước đó",
                                            className: "p-2 rounded-full bg-transparent hover:bg-yellow-100 text-gray-800 transition-all",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowRight"], {
                                                className: "w-5 h-5 transform rotate-180"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 403,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 393,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            onClick: ()=>{
                                                const container = document.getElementById('featured-products-container');
                                                if (container) {
                                                    container.scrollBy({
                                                        left: 300,
                                                        behavior: 'smooth'
                                                    });
                                                }
                                            },
                                            "aria-label": "Xem sản phẩm tiếp theo",
                                            className: "p-2 rounded-full bg-transparent hover:bg-yellow-100 text-gray-800 transition-all",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["FiArrowRight"], {
                                                className: "w-5 h-5"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 415,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 405,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 392,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 388,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            id: "featured-products-container",
                            style: {
                                scrollbarWidth: 'none',
                                msOverflowStyle: 'none',
                                WebkitOverflowScrolling: 'touch'
                            },
                            className: "jsx-a72ca76bf6e79abe" + " " + "flex overflow-x-auto pb-6 space-x-4 md:space-x-6 snap-x hide-scrollbar",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$styled$2d$jsx$2f$style$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                    id: "a72ca76bf6e79abe",
                                    children: "#featured-products-container.jsx-a72ca76bf6e79abe::-webkit-scrollbar{display:none}"
                                }, void 0, false, void 0, this),
                                featuredProducts.length === 0 ? // Placeholder sản phẩm khi không có dữ liệu
                                Array.from({
                                    length: 10
                                }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        style: {
                                            width: 'calc(100% - 1rem)',
                                            maxWidth: '280px'
                                        },
                                        className: "jsx-a72ca76bf6e79abe" + " " + "bg-white rounded-lg shadow-sm overflow-hidden flex-shrink-0 snap-start animate-pulse",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a72ca76bf6e79abe" + " " + "relative aspect-square bg-gray-300"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 441,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a72ca76bf6e79abe" + " " + "p-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-a72ca76bf6e79abe" + " " + "h-6 bg-gray-300 rounded mb-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 443,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-a72ca76bf6e79abe" + " " + "h-5 bg-gray-300 rounded w-1/2"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 444,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 442,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, `placeholder-${i}`, true, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 436,
                                        columnNumber: 17
                                    }, this)) : featuredProducts.map((product)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        href: `/product/${product.id}`,
                                        className: "group bg-white rounded-lg shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden flex-shrink-0 snap-start",
                                        style: {
                                            width: 'calc(50% - 0.5rem)',
                                            minWidth: '180px',
                                            maxWidth: '280px'
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a72ca76bf6e79abe" + " " + "relative aspect-square overflow-hidden bg-gray-100",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                        src: product.image,
                                                        alt: product.name,
                                                        fill: true,
                                                        sizes: "(min-width: 1024px) 20vw, (min-width: 768px) 25vw, 50vw",
                                                        className: "object-cover group-hover:scale-105 transition-transform duration-500",
                                                        onError: (e)=>{
                                                            console.error('Failed to load product image:', product.image);
                                                            e.currentTarget.src = '/images/product-placeholder.svg';
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 457,
                                                        columnNumber: 19
                                                    }, this),
                                                    product.originalPrice && product.originalPrice > product.price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-a72ca76bf6e79abe" + " " + "absolute top-2 left-2 bg-red-600 text-white text-xs font-medium px-2 py-1 rounded-md",
                                                        children: [
                                                            "-",
                                                            Math.round((product.originalPrice - product.price) / product.originalPrice * 100),
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 469,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 456,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "jsx-a72ca76bf6e79abe" + " " + "p-4 flex-grow flex flex-col",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: "jsx-a72ca76bf6e79abe" + " " + "text-base font-medium text-gray-900 mb-2 line-clamp-2 group-hover:text-yellow-500 transition-colors",
                                                        children: product.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 475,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "jsx-a72ca76bf6e79abe" + " " + "mt-auto",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "jsx-a72ca76bf6e79abe" + " " + "text-lg font-bold text-yellow-500",
                                                                children: formatPrice(product.price)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/page.tsx",
                                                                lineNumber: 479,
                                                                columnNumber: 21
                                                            }, this),
                                                            product.originalPrice && product.originalPrice > product.price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "jsx-a72ca76bf6e79abe" + " " + "text-sm text-gray-600 line-through",
                                                                children: formatPrice(product.originalPrice)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/page.tsx",
                                                                lineNumber: 483,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/page.tsx",
                                                        lineNumber: 478,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/page.tsx",
                                                lineNumber: 474,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, product.id, true, {
                                        fileName: "[project]/src/app/page.tsx",
                                        lineNumber: 450,
                                        columnNumber: 15
                                    }, this))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 419,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center mt-8",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                href: "/products",
                                className: "inline-block px-6 py-3 bg-yellow-500 hover:bg-yellow-600 text-white font-medium rounded-lg transition-colors",
                                children: "Xem tất cả sản phẩm"
                            }, void 0, false, {
                                fileName: "[project]/src/app/page.tsx",
                                lineNumber: 494,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 493,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 387,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 386,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "py-16 md:py-24 bg-gray-50 scroll-mt-16",
                id: "why-choose-us",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-3xl md:text-4xl font-bold text-gray-900 text-center mb-12 md:mb-20",
                            children: "Tại sao chọn LemonHub?"
                        }, void 0, false, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 504,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-16",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center group",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative w-24 h-24 md:w-32 md:h-32 bg-yellow-100 group-hover:bg-yellow-200 rounded-3xl flex items-center justify-center mx-auto mb-6 md:mb-8 transition-all duration-500 transform group-hover:scale-110 group-hover:rotate-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-4xl md:text-6xl transform transition-transform duration-500 group-hover:scale-110",
                                                    children: "🚚"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 510,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute -inset-2 bg-yellow-200 rounded-3xl -z-10 opacity-50 group-hover:opacity-100 blur-xl transition-all duration-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 511,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 509,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-xl md:text-2xl font-semibold text-gray-900 mb-4 md:mb-6",
                                            children: "Giao hàng nhanh chóng"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 513,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-base md:text-lg text-gray-700 leading-relaxed",
                                            children: "Giao hàng toàn quốc với thời gian nhanh chóng và đảm bảo an toàn cho sản phẩm."
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 514,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 508,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center group",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative w-24 h-24 md:w-32 md:h-32 bg-yellow-100 group-hover:bg-yellow-200 rounded-3xl flex items-center justify-center mx-auto mb-6 md:mb-8 transition-all duration-500 transform group-hover:scale-110 group-hover:rotate-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-4xl md:text-6xl transform transition-transform duration-500 group-hover:scale-110",
                                                    children: "💳"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 520,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute -inset-2 bg-yellow-200 rounded-3xl -z-10 opacity-50 group-hover:opacity-100 blur-xl transition-all duration-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 521,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 519,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-xl md:text-2xl font-semibold text-gray-900 mb-4 md:mb-6",
                                            children: "Thanh toán đa dạng"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 523,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-base md:text-lg text-gray-700 leading-relaxed",
                                            children: "Hỗ trợ nhiều phương thức thanh toán an toàn và tiện lợi cho khách hàng."
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 524,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 518,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "text-center group",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "relative w-24 h-24 md:w-32 md:h-32 bg-yellow-100 group-hover:bg-yellow-200 rounded-3xl flex items-center justify-center mx-auto mb-6 md:mb-8 transition-all duration-500 transform group-hover:scale-110 group-hover:rotate-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-4xl md:text-6xl transform transition-transform duration-500 group-hover:scale-110",
                                                    children: "🛡️"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 530,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "absolute -inset-2 bg-yellow-200 rounded-3xl -z-10 opacity-50 group-hover:opacity-100 blur-xl transition-all duration-500"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/page.tsx",
                                                    lineNumber: 531,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 529,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-xl md:text-2xl font-semibold text-gray-900 mb-4 md:mb-6",
                                            children: "Bảo hành chính hãng"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 533,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-base md:text-lg text-gray-700 leading-relaxed",
                                            children: "Chính sách bảo hành uy tín, đổi trả dễ dàng trong 30 ngày đầu tiên."
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/page.tsx",
                                            lineNumber: 534,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/page.tsx",
                                    lineNumber: 528,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/page.tsx",
                            lineNumber: 507,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/page.tsx",
                    lineNumber: 503,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/page.tsx",
                lineNumber: 502,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/page.tsx",
        lineNumber: 292,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=src_41811c0d._.js.map