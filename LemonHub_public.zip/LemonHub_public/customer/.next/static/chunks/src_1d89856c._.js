(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_1d89856c._.js", {

"[project]/src/services/user.service.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "addAddress": (()=>addAddress),
    "addPaymentMethod": (()=>addPaymentMethod),
    "addToWishlist": (()=>addToWishlist),
    "changePassword": (()=>changePassword),
    "checkWishlist": (()=>checkWishlist),
    "deleteAddress": (()=>deleteAddress),
    "deletePaymentMethod": (()=>deletePaymentMethod),
    "getCurrentUser": (()=>getCurrentUser),
    "getUserAddresses": (()=>getUserAddresses),
    "getUserOrders": (()=>getUserOrders),
    "getUserPaymentMethods": (()=>getUserPaymentMethods),
    "getUserWishlist": (()=>getUserWishlist),
    "removeFromWishlist": (()=>removeFromWishlist),
    "setDefaultAddress": (()=>setDefaultAddress),
    "setDefaultPaymentMethod": (()=>setDefaultPaymentMethod),
    "updateAddress": (()=>updateAddress),
    "updatePaymentMethod": (()=>updatePaymentMethod),
    "updateUserProfile": (()=>updateUserProfile),
    "uploadAvatar": (()=>uploadAvatar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/api.js [app-client] (ecmascript)");
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:5001';
const getCurrentUser = async ()=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/users/profile');
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể tải thông tin người dùng';
    }
};
const updateUserProfile = async (userData)=>{
    try {
        // Ensure we're sending all the required fields
        const dataToUpdate = {
            name: userData.name,
            email: userData.email,
            phone: userData.phone,
            address: userData.address,
            birthday: userData.birthday,
            gender: userData.gender
        };
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put('/users/profile', dataToUpdate);
        // Return the updated user data from the server
        return data;
    } catch (error) {
        console.error('Error updating profile:', error);
        throw error.response?.data?.message || 'Không thể cập nhật thông tin người dùng';
    }
};
const getUserOrders = async ()=>{
    try {
        console.log('Calling API to get user orders');
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/orders/myorders');
        console.log('Orders API response:', data);
        // Transform orders data để phù hợp với các yêu cầu hiển thị
        const formattedOrders = data.map((order)=>{
            return {
                id: order._id,
                date: order.createdAt,
                total: order.totalPrice,
                status: order.status || 'pending',
                trackingCode: order.trackingCode,
                items: order.orderItems.map((item)=>({
                        id: item._id,
                        name: item.name,
                        image: item.image,
                        price: item.price,
                        quantity: item.qty
                    }))
            };
        });
        console.log('Formatted orders for frontend:', formattedOrders);
        return formattedOrders;
    } catch (error) {
        console.error('Error fetching orders:', error.response?.data || error.message);
        throw error.response?.data?.message || 'Không thể tải danh sách đơn hàng';
    }
};
const getUserWishlist = async ()=>{
    try {
        console.log('Fetching user wishlist');
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/users/wishlist');
        // Kiểm tra dữ liệu trả về
        if (!data) {
            console.warn('No wishlist data returned from API');
            return [];
        }
        // Đảm bảo dữ liệu trả về là một mảng
        if (!Array.isArray(data)) {
            console.warn('Wishlist data is not an array:', data);
            return [];
        }
        // Log detailed wishlist data for debugging
        console.log('Raw wishlist data from API:', JSON.stringify(data));
        // Ensure each product has the correct image path
        const processedData = data.map((product)=>{
            // Force log every product to debug
            console.log('Processing wishlist product:', JSON.stringify(product));
            // Fix missing or empty image
            if (!product.image || product.image === '') {
                console.warn('Product without image:', product.id || product._id);
                return {
                    ...product,
                    image: '/images/product-placeholder.svg'
                };
            }
            // Complete image URLs if they're relative paths
            let imageUrl = product.image;
            if (imageUrl && !imageUrl.startsWith('http') && !imageUrl.startsWith('/')) {
                imageUrl = `/${imageUrl}`;
            }
            if (imageUrl && !imageUrl.startsWith('http') && imageUrl.startsWith('/')) {
                imageUrl = `${API_URL}${imageUrl}`;
            }
            return {
                ...product,
                image: imageUrl
            };
        });
        console.log('Wishlist loaded successfully:', processedData.length, 'items');
        console.log('Processed wishlist items IDs:', processedData.map((item)=>item.id || item._id));
        return processedData;
    } catch (error) {
        console.error('Error fetching wishlist:', error);
        console.error('Error details:', error.response?.data || error.message);
        // Check if it's an authentication error
        if (error.response?.status === 401) {
            console.warn('Authentication error when fetching wishlist - token may be invalid');
        }
        // Return empty array instead of throwing error to prevent UI failures
        return [];
    }
};
const addToWishlist = async (productId)=>{
    try {
        console.log('Adding product to wishlist:', productId);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/users/wishlist', {
            productId
        });
        if (data.success) {
            console.log('Product added to wishlist successfully');
        }
        return data;
    } catch (error) {
        console.error('Error adding to wishlist:', error.response?.data || error);
        throw error.response?.data?.message || 'Không thể thêm sản phẩm vào danh sách yêu thích';
    }
};
const removeFromWishlist = async (productId)=>{
    try {
        console.log('Removing product from wishlist:', productId);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`/users/wishlist/${productId}`);
        if (data.success) {
            console.log('Product removed from wishlist successfully');
        }
        return data;
    } catch (error) {
        console.error('Error removing from wishlist:', error.response?.data || error);
        throw error.response?.data?.message || 'Không thể xóa sản phẩm khỏi danh sách yêu thích';
    }
};
const checkWishlist = async (productId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/users/wishlist/${productId}`);
        return data.inWishlist;
    } catch (error) {
        console.error('Error checking wishlist status:', error);
        return false;
    }
};
const getUserAddresses = async (forceReload = false)=>{
    try {
        console.log('Đang tải danh sách địa chỉ', forceReload ? '(bắt buộc tải mới)' : '');
        // Tạo URL endpoing chính xác 
        const endpoint = '/users/addresses';
        console.log(`Gửi yêu cầu API đến: ${endpoint}`);
        // Lấy dữ liệu từ API server
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(endpoint);
        // Ghi log thông tin chi tiết dữ liệu trả về
        console.log('Dữ liệu địa chỉ gốc từ server (raw):', JSON.stringify(data));
        // Kiểm tra dữ liệu trả về
        if (!data) {
            console.warn('Không có dữ liệu địa chỉ trả về từ API');
            return [];
        }
        // Đảm bảo dữ liệu trả về là một mảng
        if (!Array.isArray(data)) {
            console.warn('Dữ liệu địa chỉ không phải là mảng:', typeof data, data);
            // Nếu là object có thuộc tính addresses là mảng, trả về addresses
            if (data && typeof data === 'object' && Array.isArray(data.addresses)) {
                console.log('Nhận dạng format response có field addresses, sử dụng data.addresses');
                return data.addresses;
            }
            return [];
        }
        console.log('Đã tải thành công', data.length, 'địa chỉ từ server');
        // Kiểm tra và log từng địa chỉ trong mảng
        data.forEach((address, index)=>{
            console.log(`Địa chỉ #${index + 1}:`, JSON.stringify(address));
            // Kiểm tra xem mỗi địa chỉ có thuộc tính id không, nếu không thì dùng _id
            if (!address.id && address._id) {
                console.log(`Chuyển đổi _id thành id cho địa chỉ #${index + 1}`);
                address.id = address._id;
            }
        });
        // Đảm bảo mỗi địa chỉ đều có thuộc tính id và các thuộc tính cần thiết
        const processedAddresses = data.map((address)=>{
            // Đảm bảo các trường cần thiết đều có
            return {
                id: address.id || address._id || 'unknown-id',
                fullName: address.fullName || 'Không có tên',
                phone: address.phone || 'Không có SĐT',
                address: address.address || 'Không có địa chỉ',
                isDefault: !!address.isDefault
            };
        });
        console.log('Địa chỉ sau khi xử lý:', JSON.stringify(processedAddresses));
        // Cập nhật localStorage
        try {
            const userInfoStr = localStorage.getItem('userInfo');
            if (userInfoStr) {
                const userInfo = JSON.parse(userInfoStr);
                if (userInfo && userInfo._id) {
                    userInfo.addresses = processedAddresses;
                    localStorage.setItem('userInfo', JSON.stringify(userInfo));
                    console.log('Đã cập nhật địa chỉ trong localStorage từ phản hồi API');
                }
            }
        } catch (e) {
            console.warn('Không thể cập nhật địa chỉ trong localStorage:', e);
        }
        return processedAddresses;
    } catch (error) {
        console.error('Lỗi khi tải địa chỉ:', error);
        console.error('Chi tiết lỗi:', error.response?.data || error.message);
        console.error('Config URL:', error.config?.url);
        console.error('Request headers:', error.config?.headers);
        // Kiểm tra nếu là lỗi xác thực
        if (error.response?.status === 401) {
            console.warn('Lỗi xác thực khi tải địa chỉ - token có thể không hợp lệ');
        }
        // Trả về mảng rỗng thay vì ném lỗi để tránh lỗi giao diện
        return [];
    }
};
const addAddress = async (addressData)=>{
    try {
        console.log('Adding new address:', addressData);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/users/addresses', addressData);
        console.log('Address added successfully:', data);
        // Update addresses in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id) {
                if (!Array.isArray(userInfo.addresses)) {
                    userInfo.addresses = [];
                }
                userInfo.addresses.push(data);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with new address');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with new address:', localStorageError);
        }
        return data;
    } catch (error) {
        console.error('Error adding address:', error);
        throw error.response?.data?.message || 'Không thể thêm địa chỉ mới';
    }
};
const updateAddress = async (addressId, addressData)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/users/addresses/${addressId}`, addressData);
        // Update addresses in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.addresses)) {
                userInfo.addresses = userInfo.addresses.map((addr)=>addr.id === addressId ? {
                        ...addr,
                        ...data
                    } : addr);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with updated address');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with updated address:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể cập nhật địa chỉ';
    }
};
const deleteAddress = async (addressId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`/users/addresses/${addressId}`);
        // Update addresses in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.addresses)) {
                userInfo.addresses = userInfo.addresses.filter((addr)=>addr.id !== addressId);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage after removing address');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage after removing address:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể xóa địa chỉ';
    }
};
const setDefaultAddress = async (addressId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/users/addresses/${addressId}/default`);
        // Update addresses in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.addresses)) {
                userInfo.addresses = userInfo.addresses.map((addr)=>({
                        ...addr,
                        isDefault: addr.id === addressId
                    }));
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with default address change');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with default address change:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể đặt địa chỉ mặc định';
    }
};
const changePassword = async (passwordData)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put('/users/change-password', passwordData);
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể thay đổi mật khẩu';
    }
};
const uploadAvatar = async (file)=>{
    try {
        console.log('User service: Uploading avatar file', file.name, 'size:', file.size);
        const formData = new FormData();
        formData.append('avatar', file);
        // Gọi API để upload avatar
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/users/upload-avatar', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('Upload avatar API response:', response.data);
        // Check if the response has the avatar path
        if (!response.data || !response.data.avatarUrl) {
            console.error('Avatar path not found in API response:', response.data);
            throw new Error('Avatar path not found in response');
        }
        let avatarUrl = response.data.avatarUrl;
        // Ensure the avatar URL is complete
        if (!avatarUrl.startsWith('http') && !avatarUrl.startsWith('/')) {
            avatarUrl = `/${avatarUrl}`;
        }
        if (!avatarUrl.startsWith('http') && avatarUrl.startsWith('/')) {
            avatarUrl = `${API_URL}${avatarUrl}`;
        }
        // Add a timestamp to prevent caching
        const timestamp = Date.now();
        avatarUrl = avatarUrl.includes('?') ? `${avatarUrl}&t=${timestamp}` : `${avatarUrl}?t=${timestamp}`;
        console.log('Final avatar URL with cache busting:', avatarUrl);
        // Update the user profile in the session storage
        const user = JSON.parse(sessionStorage.getItem('user') || '{}');
        user.avatar = avatarUrl;
        sessionStorage.setItem('user', JSON.stringify(user));
        // Return the updated user with the avatar URL
        return {
            ...response.data,
            avatar: avatarUrl
        };
    } catch (error) {
        console.error('Error uploading avatar:', error);
        throw error;
    }
};
const getUserPaymentMethods = async ()=>{
    try {
        console.log('Đang tải phương thức thanh toán');
        // Tạo URL endpoint chính xác
        const endpoint = '/users/payment-methods';
        console.log(`Gửi yêu cầu API đến: ${endpoint}`);
        // Lấy dữ liệu từ API server
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(endpoint);
        // Ghi log thông tin chi tiết dữ liệu trả về
        console.log('Dữ liệu phương thức thanh toán từ server (raw):', JSON.stringify(data));
        // Kiểm tra dữ liệu trả về
        if (!data) {
            console.warn('Không có dữ liệu phương thức thanh toán trả về từ API');
            return [];
        }
        // Đảm bảo dữ liệu trả về là một mảng
        if (!Array.isArray(data)) {
            console.warn('Dữ liệu phương thức thanh toán không phải là mảng:', typeof data, data);
            // Nếu là object có thuộc tính paymentMethods là mảng, trả về paymentMethods
            if (data && typeof data === 'object' && Array.isArray(data.paymentMethods)) {
                console.log('Nhận dạng format response có field paymentMethods, sử dụng data.paymentMethods');
                return data.paymentMethods;
            }
            return [];
        }
        console.log('Đã tải thành công', data.length, 'phương thức thanh toán từ server');
        // Kiểm tra và đảm bảo mỗi phương thức thanh toán đều có thuộc tính id
        const processedPaymentMethods = data.map((method, index)=>{
            console.log(`Phương thức thanh toán #${index + 1}:`, JSON.stringify(method));
            // Chuyển đổi _id thành id nếu cần
            if (!method.id && method._id) {
                console.log(`Chuyển đổi _id thành id cho phương thức thanh toán #${index + 1}`);
                method.id = method._id;
            }
            // Đảm bảo các trường cần thiết đều có
            return {
                id: method.id || method._id || 'unknown-id',
                type: method.type || 'unknown',
                cardNumber: method.cardNumber || '',
                expiryDate: method.expiryDate || '',
                isDefault: !!method.isDefault,
                bankName: method.bankName || '',
                cardType: method.cardType || ''
            };
        });
        console.log('Phương thức thanh toán sau khi xử lý:', JSON.stringify(processedPaymentMethods));
        // Cập nhật localStorage
        try {
            const userInfoStr = localStorage.getItem('userInfo');
            if (userInfoStr) {
                const userInfo = JSON.parse(userInfoStr);
                if (userInfo && userInfo._id) {
                    userInfo.paymentMethods = processedPaymentMethods;
                    localStorage.setItem('userInfo', JSON.stringify(userInfo));
                    console.log('Đã cập nhật phương thức thanh toán trong localStorage từ phản hồi API');
                }
            }
        } catch (e) {
            console.warn('Không thể cập nhật phương thức thanh toán trong localStorage:', e);
        }
        return processedPaymentMethods;
    } catch (error) {
        console.error('Lỗi khi tải phương thức thanh toán:', error);
        console.error('Chi tiết lỗi:', error.response?.data || error.message);
        console.error('Config URL:', error.config?.url);
        console.error('Request headers:', error.config?.headers);
        // Kiểm tra nếu là lỗi xác thực
        if (error.response?.status === 401) {
            console.warn('Lỗi xác thực khi tải phương thức thanh toán - token có thể không hợp lệ');
        }
        // Trả về mảng rỗng thay vì ném lỗi để tránh lỗi giao diện
        return [];
    }
};
const addPaymentMethod = async (paymentData)=>{
    try {
        console.log('Adding new payment method:', paymentData);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/users/payment-methods', paymentData);
        console.log('Payment method added successfully:', data);
        // Update payment methods in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id) {
                if (!Array.isArray(userInfo.paymentMethods)) {
                    userInfo.paymentMethods = [];
                }
                userInfo.paymentMethods.push(data);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with new payment method');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with new payment method:', localStorageError);
        }
        return data;
    } catch (error) {
        console.error('Error adding payment method:', error);
        throw error.response?.data?.message || 'Không thể thêm phương thức thanh toán mới';
    }
};
const updatePaymentMethod = async (paymentId, paymentData)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/users/payment-methods/${paymentId}`, paymentData);
        // Update payment methods in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.paymentMethods)) {
                userInfo.paymentMethods = userInfo.paymentMethods.map((method)=>method.id === paymentId ? {
                        ...method,
                        ...data
                    } : method);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with updated payment method');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with updated payment method:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể cập nhật phương thức thanh toán';
    }
};
const deletePaymentMethod = async (paymentId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`/users/payment-methods/${paymentId}`);
        // Update payment methods in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.paymentMethods)) {
                userInfo.paymentMethods = userInfo.paymentMethods.filter((method)=>method.id !== paymentId);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage after removing payment method');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage after removing payment method:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể xóa phương thức thanh toán';
    }
};
const setDefaultPaymentMethod = async (paymentId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/users/payment-methods/${paymentId}/default`);
        // Update payment methods in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.paymentMethods)) {
                userInfo.paymentMethods = userInfo.paymentMethods.map((method)=>({
                        ...method,
                        isDefault: method.id === paymentId
                    }));
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with default payment method change');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with default payment method change:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể đặt phương thức thanh toán mặc định';
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/hooks/useAuth.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "useAuth": (()=>useAuth)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/context/AuthContext.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hot-toast/dist/index.mjs [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
const useAuth = ()=>{
    _s();
    const { state, dispatch } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$context$2f$AuthContext$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthContext"]);
    const isLoggedIn = !!state.userInfo;
    const openAuthModal = ()=>{
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Vui lòng đăng nhập để thực hiện chức năng này');
        setTimeout(()=>{
            window.location.href = '/login';
        }, 1000);
    };
    const logout = ()=>{
        dispatch({
            type: 'USER_LOGOUT'
        });
        localStorage.removeItem('userInfo');
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Đã đăng xuất');
        window.location.href = '/login';
    };
    return {
        user: state.userInfo,
        isLoggedIn,
        openAuthModal,
        logout,
        loading: state.loading
    };
};
_s(useAuth, "QMdo+h1+fLbTriZQ0QN6uukzyow=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/utils/image.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getFullImageUrl": (()=>getFullImageUrl)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const getFullImageUrl = (imagePath)=>{
    // Debug info
    console.log('Original image path:', imagePath);
    // Check for empty or undefined paths
    if (!imagePath) {
        console.log('Image path is empty, using placeholder');
        return '/images/product-placeholder.svg';
    }
    // If the image URL is already absolute, return it as is
    if (imagePath.startsWith('http')) {
        console.log('Image path is already absolute');
        return imagePath;
    }
    // For server-side paths that start with /uploads
    if (imagePath.startsWith('/uploads')) {
        const serverUrl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:5001';
        const fullUrl = `${serverUrl}${imagePath}`;
        console.log('Server image path, resolved to:', fullUrl);
        return fullUrl;
    }
    // Hardcode the base URL for testing if environment variable is not set
    const baseUrl = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:5001';
    console.log('Using base URL:', baseUrl);
    // Remove trailing slash from base URL if it exists
    const cleanBaseUrl = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
    // Add leading slash to image path if it doesn't exist
    const cleanImagePath = imagePath.startsWith('/') ? imagePath : `/${imagePath}`;
    // Combine base URL and image path
    const fullUrl = `${cleanBaseUrl}${cleanImagePath}`;
    console.log('Resolved full URL:', fullUrl);
    return fullUrl;
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/services/product.service.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "createProduct": (()=>createProduct),
    "createProductReview": (()=>createProductReview),
    "deleteProduct": (()=>deleteProduct),
    "getAllProducts": (()=>getAllProducts),
    "getBanners": (()=>getBanners),
    "getBestSellingProducts": (()=>getBestSellingProducts),
    "getFeaturedProducts": (()=>getFeaturedProducts),
    "getNewProducts": (()=>getNewProducts),
    "getNewestProducts": (()=>getNewestProducts),
    "getProductById": (()=>getProductById),
    "getProductBySlug": (()=>getProductBySlug),
    "getProductReviews": (()=>getProductReviews),
    "getProductsByCategory": (()=>getProductsByCategory),
    "getRelatedProducts": (()=>getRelatedProducts),
    "getTopRatedProducts": (()=>getTopRatedProducts),
    "searchProducts": (()=>searchProducts),
    "updateProduct": (()=>updateProduct),
    "updateStatus": (()=>updateStatus),
    "updateStock": (()=>updateStock)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/api.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/utils/image.ts [app-client] (ecmascript)");
;
;
// Hàm chuyển đổi dữ liệu sản phẩm từ API sang định dạng frontend
const transformProduct = (product)=>{
    // Kiểm tra xem product có tồn tại không
    if (!product) return null;
    // Đảm bảo đường dẫn ảnh đầy đủ
    const mainImage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFullImageUrl"])(product.image);
    // Xử lý mảng ảnh phụ (chỉ lấy những ảnh phụ khác với ảnh chính)
    let additionalImages = [];
    if (Array.isArray(product.images) && product.images.length > 0) {
        additionalImages = product.images.map(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFullImageUrl"]).filter((img)=>img && img !== mainImage); // Loại bỏ ảnh trùng với ảnh chính và ảnh null
    }
    // Tạo mảng đầy đủ các ảnh, với ảnh chính ở đầu tiên
    const allImages = [
        mainImage,
        ...additionalImages
    ];
    // Chuyển đổi specifications từ Map sang mảng các đối tượng
    let specifications = [];
    if (product.specifications) {
        if (product.specifications instanceof Map) {
            // Nếu specifications là Map
            for (const [key, value] of product.specifications.entries()){
                specifications.push({
                    name: key,
                    value: value
                });
            }
        } else if (typeof product.specifications === 'object') {
            // Nếu specifications là object thông thường
            specifications = Object.entries(product.specifications).map(([key, value])=>({
                    name: key,
                    value: value
                }));
        }
    }
    return {
        id: product._id || product.id || '',
        name: product.name || 'Sản phẩm',
        slug: product.slug || '',
        price: product.price || 0,
        originalPrice: product.salePrice || product.originalPrice || product.price || 0,
        image: mainImage,
        images: allImages,
        description: product.description || '',
        brand: product.brand || '',
        category: product.category ? {
            id: product.category._id || product.category.id || '',
            name: product.category.name || ''
        } : null,
        countInStock: product.countInStock || 0,
        stock: product.countInStock || product.stock || 0,
        rating: product.rating || 0,
        numReviews: product.numReviews || 0,
        isFeatured: Boolean(product.isFeatured),
        specifications: specifications // Thêm specifications vào dữ liệu trả về
    };
};
// Dữ liệu mẫu cho sản phẩm
const FALLBACK_PRODUCTS = [
    {
        id: 'fallback1',
        name: 'Laptop Gaming Asus',
        price: 25990000,
        originalPrice: 29990000,
        image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
    },
    {
        id: 'fallback2',
        name: 'Samsung Galaxy S23 Ultra',
        price: 18990000,
        originalPrice: 21990000,
        image: 'https://images.unsplash.com/photo-1598327105666-5b89351aff97?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
    },
    {
        id: 'fallback3',
        name: 'Apple iPad Pro',
        price: 29990000,
        originalPrice: 35990000,
        image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80'
    }
];
// Dữ liệu mẫu cho banner
const FALLBACK_BANNERS = [
    {
        id: 1,
        title: "Trải nghiệm công nghệ tốt nhất",
        subtitle: "Các sản phẩm chất lượng cao với mức giá hợp lý",
        image: "https://images.unsplash.com/photo-1498049794561-7780e7231661?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1500&q=80"
    },
    {
        id: 2,
        title: "Thiết bị thông minh cho cuộc sống",
        subtitle: "Khám phá bộ sưu tập thiết bị mới nhất",
        image: "https://images.unsplash.com/photo-1531297484001-80022131f5a1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1500&q=80"
    }
];
// Hàm chuyển đổi mảng sản phẩm
const transformProducts = (data)=>{
    try {
        // First check if data is null or undefined
        if (!data) {
            console.warn('Empty data passed to transformProducts');
            return [];
        }
        // Check if data is already an array of products
        if (Array.isArray(data)) {
            console.log('Data is array, mapping directly:', data.length, 'items');
            return data.map(transformProduct).filter(Boolean);
        }
        // Check if data has a 'products' property that is an array
        if (data.products && Array.isArray(data.products)) {
            console.log('Data has products array:', data.products.length, 'items');
            return data.products.map(transformProduct).filter(Boolean);
        }
        console.warn('Invalid products data structure:', data);
        return [];
    } catch (error) {
        console.error('Error transforming products:', error);
        return [];
    }
};
const getAllProducts = async (params)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/products', {
            params
        });
        return {
            ...data,
            products: transformProducts(data)
        };
    } catch (error) {
        console.error('Error in getAllProducts:', error);
        return {
            products: FALLBACK_PRODUCTS,
            page: 1,
            pages: 1,
            total: FALLBACK_PRODUCTS.length
        };
    }
};
const getProductById = async (id)=>{
    try {
        console.log('Fetching product with ID:', id);
        // Fetch the product details
        const { data: product } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/${id}`);
        console.log('Raw product data:', product);
        const transformedProduct = transformProduct(product);
        console.log('Transformed product:', transformedProduct);
        return transformedProduct;
    } catch (error) {
        console.error('Error in getProductById:', error);
        // Fallback to a dummy product if real data couldn't be fetched
        return FALLBACK_PRODUCTS.find((p)=>p.id === id) || FALLBACK_PRODUCTS[0];
    }
};
const getProductBySlug = async (slug)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/slug/${slug}`);
        return transformProduct(data);
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch product by slug';
    }
};
const searchProducts = async (keyword, page = 1, limit = 10)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/products', {
            params: {
                keyword,
                page,
                limit
            }
        });
        return {
            ...data,
            products: transformProducts(data)
        };
    } catch (error) {
        throw error.response?.data?.message || 'Could not search products';
    }
};
const getProductsByCategory = async (categoryId, page = 1, limit = 12, sort = '')=>{
    try {
        console.log('Fetching products for category:', categoryId);
        // Convert frontend sort values to API sort parameters
        let sortParam = '';
        switch(sort){
            case 'newest':
                sortParam = '-createdAt';
                break;
            case 'price-asc':
                sortParam = 'price';
                break;
            case 'price-desc':
                sortParam = '-price';
                break;
            case 'name-asc':
                sortParam = 'name';
                break;
            case 'name-desc':
                sortParam = '-name';
                break;
            case 'popular':
                sortParam = '-numSales';
                break;
            case 'rating':
                sortParam = '-rating';
                break;
            default:
                sortParam = '-createdAt';
        }
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/category/${categoryId}`, {
            params: {
                page,
                limit,
                sort: sortParam
            }
        });
        // Transform the response data
        const transformedData = {
            products: transformProducts(data),
            page: data.page,
            pages: data.pages,
            total: data.total,
            category: data.category
        };
        console.log('Transformed category products:', transformedData);
        return transformedData;
    } catch (error) {
        console.error('Error in getProductsByCategory:', error);
        throw error.response?.data?.message || 'Could not fetch products by category';
    }
};
const createProductReview = async (productId, review)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(`/products/${productId}/reviews`, review);
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Could not create product review';
    }
};
const getFeaturedProducts = async (limit = 8)=>{
    try {
        console.log('Fetching featured products with limit:', limit);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/featured`, {
            params: {
                limit
            }
        });
        console.log('Received featured products data:', data);
        // Kiểm tra dữ liệu trước khi chuyển đổi
        if (!data) {
            console.warn('Empty data received from featured products API');
            return FALLBACK_PRODUCTS;
        }
        const transformed = transformProducts(data);
        console.log('Transformed featured products:', transformed);
        // Nếu không có sản phẩm nổi bật, trả về sản phẩm mẫu
        if (!transformed || transformed.length === 0) {
            console.log('No featured products found, using fallbacks');
            return FALLBACK_PRODUCTS;
        }
        return transformed;
    } catch (error) {
        console.error('Error in getFeaturedProducts:', error);
        // Return fallback products instead of throwing
        return FALLBACK_PRODUCTS;
    }
};
const getNewProducts = async (limit = 8)=>{
    try {
        console.log('Fetching newest products with limit:', limit);
        // Updated to use the correct endpoint
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/newest`, {
            params: {
                limit
            }
        });
        // Extra check to ensure data is valid
        if (!data || !Array.isArray(data)) {
            console.error('Invalid data received for newest products:', data);
            return [];
        }
        console.log('Received newest products data:', data.length, 'items');
        // Process each product to ensure valid image URLs
        const productsWithImages = data.map((product)=>{
            if (!product.image || product.image === '') {
                console.warn('Product without image:', product._id);
                // Set a default image
                product.image = '/images/product-placeholder.svg';
            }
            return product;
        });
        const transformed = transformProducts(productsWithImages);
        console.log('Transformed newest products:', transformed.length, 'items');
        return transformed;
    } catch (error) {
        console.error('Error in getNewProducts:', error);
        // Return empty array instead of throwing to prevent UI errors
        return [];
    }
};
const getTopRatedProducts = async (limit = 3)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/top`, {
            params: {
                limit
            }
        });
        return transformProducts(data);
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch top rated products';
    }
};
const getRelatedProducts = async (productId, limit = 4)=>{
    try {
        console.log('Fetching related products for ID:', productId);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/${productId}/related`, {
            params: {
                limit
            }
        });
        // API trả về { products: [...] }
        const productsArray = data.products || data;
        // Check if data exists and is an array
        if (!productsArray || !Array.isArray(productsArray)) {
            console.warn('Invalid data structure returned for related products:', data);
            return [];
        }
        // Ensure all products have valid images
        const productsWithImages = productsArray.map((product)=>{
            if (!product.image || product.image === '') {
                console.warn('Related product without image:', product._id);
                product.image = '/images/product-placeholder.svg';
            }
            return product;
        });
        const transformed = productsArray.map(transformProduct).filter(Boolean);
        console.log('Successfully fetched related products:', transformed.length, 'items');
        return transformed;
    } catch (error) {
        console.error('Error in getRelatedProducts:', error);
        // Return empty array instead of throwing to prevent UI errors
        return [];
    }
};
const getProductReviews = async (productId, page = 1, limit = 10)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/${productId}/reviews`, {
            params: {
                page,
                limit
            }
        });
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch product reviews';
    }
};
const getBestSellingProducts = async (limit = 8)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/best-selling`, {
            params: {
                limit
            }
        });
        return transformProducts(data);
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch best selling products';
    }
};
const getBanners = async ()=>{
    try {
        console.log('Fetching banners');
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/banners');
        console.log('Received banners data:', data);
        // Kiểm tra dữ liệu trước khi xử lý
        if (!data || !Array.isArray(data) || data.length === 0) {
            console.warn('No banners data received or invalid format');
            return FALLBACK_BANNERS;
        }
        // Chuyển đổi _id thành id cho banners và đảm bảo đường dẫn ảnh đầy đủ
        const transformed = data.map((banner)=>{
            if (!banner) return null;
            // Process image path using our utility
            const imagePath = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$utils$2f$image$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFullImageUrl"])(banner.image);
            return {
                id: banner._id || banner.id || Math.random().toString(36).substr(2, 9),
                title: banner.title || 'Công nghệ mới',
                subtitle: banner.subtitle || 'Khám phá các sản phẩm mới nhất',
                image: imagePath || FALLBACK_BANNERS[0].image,
                link: banner.link || '',
                isActive: banner.isActive || true
            };
        }).filter(Boolean);
        if (transformed.length === 0) {
            console.warn('No valid banners after transformation');
            return FALLBACK_BANNERS;
        }
        console.log('Transformed banners:', transformed);
        return transformed;
    } catch (error) {
        console.error('Error in getBanners:', error);
        return FALLBACK_BANNERS;
    }
};
const createProduct = async (productData)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/products', productData);
    return response.data;
};
const updateProduct = async (id, productData)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/products/${id}`, productData);
    return response.data;
};
const deleteProduct = async (id)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`/products/${id}`);
    return response.data;
};
const updateStock = async (id, stock)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].patch(`/products/${id}/stock`, {
        stock
    });
    return response.data;
};
const updateStatus = async (id, isActive)=>{
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].patch(`/products/${id}/status`, {
        isActive
    });
    return response.data;
};
const getNewestProducts = async (limit = 8)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/products/newest`, {
            params: {
                limit
            }
        });
        return transformProducts(data);
    } catch (error) {
        throw error.response?.data?.message || 'Could not fetch newest products';
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/product/[id]/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$cart$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/cart.service.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hot-toast/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$user$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/user.service.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/ai/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$cg$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/cg/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useAuth.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$product$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/product.service.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
const formatPrice = (price)=>{
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(price);
};
const calculateDiscount = (originalPrice, price)=>{
    return Math.round((originalPrice - price) / originalPrice * 100);
};
// Tạo các hàm wrapper để kèm thêm log và xử lý lỗi
const fetchProductDetails = async (id)=>{
    try {
        const productData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$product$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getProductById"])(id);
        return productData;
    } catch (error) {
        console.error('Error fetching product details:', error);
        return null;
    }
};
const fetchRelatedProducts = async (productId)=>{
    console.log('Fetching related products for product ID:', productId);
    try {
        const related = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$product$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getRelatedProducts"])(productId);
        console.log('Related products fetched successfully:', related?.length);
        return related;
    } catch (error) {
        console.error('Failed to fetch related products:', error);
        return []; // Return empty array instead of throwing to avoid blocking rendering
    }
};
const checkProductInWishlist = async (productId)=>{
    console.log('Checking if product is in wishlist:', productId);
    try {
        const isInWishlist = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$user$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["checkWishlist"])(productId);
        console.log('Product wishlist status:', isInWishlist ? 'In wishlist' : 'Not in wishlist');
        return isInWishlist;
    } catch (error) {
        console.error('Failed to check wishlist status:', error);
        return false; // Default to not in wishlist on error
    }
};
const ProductDetailPage = ({ params })=>{
    _s();
    const { id } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].use(params);
    const navigate = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [quantity, setQuantity] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [product, setProduct] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [relatedProducts, setRelatedProducts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [addingToCart, setAddingToCart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { isLoggedIn, openAuthModal } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const [inWishlist, setInWishlist] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [wishlistLoading, setWishlistLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [selectedImage, setSelectedImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [selectedVariants, setSelectedVariants] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({});
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [notFound, setNotFound] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [isAuthModalOpen, setIsAuthModalOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [currentUrl, setCurrentUrl] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductDetailPage.useEffect": ()=>{
            const fetchProduct = {
                "ProductDetailPage.useEffect.fetchProduct": async ()=>{
                    try {
                        setLoading(true);
                        console.log('Starting to fetch product data for ID:', id);
                        const product = await fetchProductDetails(id);
                        if (!product) {
                            console.warn('Product not found for ID:', id);
                            setNotFound(true);
                            setLoading(false);
                            return;
                        }
                        // Ensure product.category is always valid
                        const safeProduct = {
                            ...product,
                            category: product.category || {
                                id: '',
                                name: ''
                            }
                        };
                        setProduct(safeProduct);
                        // Fetch related products in parallel with wishlist check
                        const relatedPromise = fetchRelatedProducts(product.id);
                        // Check wishlist status if user is logged in
                        let wishlistPromise = Promise.resolve(false);
                        if (isLoggedIn) {
                            wishlistPromise = checkProductInWishlist(id);
                        }
                        // Wait for both promises to resolve
                        const [related, isInWishlist] = await Promise.all([
                            relatedPromise,
                            wishlistPromise
                        ]);
                        if (related && related.length > 0) {
                            const formattedRelatedProducts = related.filter({
                                "ProductDetailPage.useEffect.fetchProduct.formattedRelatedProducts": (item)=>item !== null
                            }["ProductDetailPage.useEffect.fetchProduct.formattedRelatedProducts"]).map({
                                "ProductDetailPage.useEffect.fetchProduct.formattedRelatedProducts": (item)=>({
                                        id: item.id,
                                        name: item.name || '',
                                        price: item.price || 0,
                                        originalPrice: item.originalPrice || item.price || 0,
                                        discount: item.discount || 0,
                                        image: item.image || '/images/product-placeholder.svg',
                                        images: item.images || [],
                                        description: item.description || '',
                                        category: {
                                            id: item.category?.id || '',
                                            name: item.category?.name || ''
                                        },
                                        brand: item.brand || '',
                                        stock: item.stock || item.countInStock || 0
                                    })
                            }["ProductDetailPage.useEffect.fetchProduct.formattedRelatedProducts"]);
                            setRelatedProducts(formattedRelatedProducts);
                        }
                        // Update wishlist status if user is logged in
                        if (isLoggedIn) {
                            setInWishlist(isInWishlist);
                        }
                        setLoading(false);
                    } catch (error) {
                        console.error('Error in fetchProduct:', error);
                        setError(typeof error === 'string' ? error : 'Failed to load product');
                        setLoading(false);
                    }
                }
            }["ProductDetailPage.useEffect.fetchProduct"];
            fetchProduct();
        }
    }["ProductDetailPage.useEffect"], [
        id,
        isLoggedIn
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProductDetailPage.useEffect": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                setCurrentUrl(window.location.pathname + window.location.search);
            }
        }
    }["ProductDetailPage.useEffect"], []);
    const handleQuantityChange = (value)=>{
        if (value < 1) return;
        if (product && value > product.stock) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(`Chỉ còn ${product.stock} sản phẩm trong kho`);
            return;
        }
        setQuantity(value);
    };
    const handleAddToCart = async ()=>{
        // Check if user is logged in by checking userInfo, not just token
        const userInfo = localStorage.getItem('userInfo');
        if (!userInfo) {
            console.log('User not logged in. Opening auth modal...');
            setIsAuthModalOpen(true);
            return;
        }
        setAddingToCart(true);
        try {
            // Convert selected variants to array of objects
            const selectedOptions = Object.entries(selectedVariants).map(([key, value])=>({
                    name: key,
                    value: value
                }));
            if (product) {
                console.log('Adding to cart:', {
                    productId: product.id,
                    quantity,
                    options: selectedOptions
                });
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$cart$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addToCart"])(product.id, quantity, selectedOptions);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Sản phẩm đã được thêm vào giỏ hàng');
                // Force a hard refresh to update the cart count in header
                window.location.reload();
            }
        } catch (error) {
            console.error('Error adding to cart:', error);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(error.message || 'Có lỗi xảy ra khi thêm vào giỏ hàng');
        } finally{
            setAddingToCart(false);
        }
    };
    const handleToggleWishlist = async ()=>{
        if (!isLoggedIn) {
            openAuthModal();
            return;
        }
        try {
            setWishlistLoading(true);
            if (inWishlist) {
                // Remove from wishlist
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$user$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeFromWishlist"])(id);
                setInWishlist(false);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Đã xóa khỏi danh sách yêu thích');
            } else {
                // Add to wishlist
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$user$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addToWishlist"])(id);
                setInWishlist(true);
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Đã thêm vào danh sách yêu thích');
            }
        } catch (error) {
            console.error('Wishlist operation failed:', error);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(typeof error === 'string' ? error : 'Không thể cập nhật danh sách yêu thích');
        } finally{
            setWishlistLoading(false);
        }
    };
    const handleShare = ()=>{
        if (navigator.share) {
            navigator.share({
                title: product?.name,
                text: product?.description,
                url: window.location.href
            });
        }
    };
    const productImages = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ProductDetailPage.useMemo[productImages]": ()=>{
            if (!product || !product.images || !Array.isArray(product.images) || product.images.length === 0) {
                console.log('No valid images found for product');
                return [];
            }
            // Sử dụng mảng images trực tiếp từ product
            // TransformProduct đã xử lý mảng này để bao gồm cả ảnh chính và ảnh phụ
            console.log('Product images array:', product.images);
            console.log('Number of images:', product.images.length);
            return product.images;
        }
    }["ProductDetailPage.useMemo[productImages]"], [
        product
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-gradient-to-br from-gray-50 to-white py-12",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "flex mb-8",
                        "aria-label": "Breadcrumb",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                            className: "flex items-center space-x-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/",
                                        className: "text-gray-700 hover:text-yellow-500 transition-colors",
                                        children: "Trang chủ"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                        lineNumber: 320,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                    lineNumber: 319,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronLeft"], {
                                        className: "w-5 h-5 text-gray-600"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                        lineNumber: 328,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                    lineNumber: 327,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/product",
                                        className: "text-gray-700 hover:text-yellow-500 transition-colors",
                                        children: "Sản phẩm"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                        lineNumber: 331,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                    lineNumber: 330,
                                    columnNumber: 15
                                }, this),
                                product?.category && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronLeft"], {
                                                className: "w-5 h-5 text-gray-600"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                lineNumber: 341,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/product/[id]/page.tsx",
                                            lineNumber: 340,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                href: `/category/${product.category.id}`,
                                                className: "text-gray-700 hover:text-yellow-500 transition-colors",
                                                children: product.category.name
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                lineNumber: 344,
                                                columnNumber: 21
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/product/[id]/page.tsx",
                                            lineNumber: 343,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/product/[id]/page.tsx",
                            lineNumber: 318,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/product/[id]/page.tsx",
                        lineNumber: 317,
                        columnNumber: 11
                    }, this),
                    loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-center items-center min-h-[400px]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "animate-spin rounded-full h-8 w-8 border-b-2 border-yellow-500"
                        }, void 0, false, {
                            fileName: "[project]/src/app/product/[id]/page.tsx",
                            lineNumber: 358,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/product/[id]/page.tsx",
                        lineNumber: 357,
                        columnNumber: 13
                    }, this) : error ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center py-12",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-medium text-gray-900 mb-2",
                                children: error
                            }, void 0, false, {
                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                lineNumber: 362,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/product",
                                className: "text-yellow-500 hover:text-yellow-600 transition-colors",
                                children: "Quay lại trang sản phẩm"
                            }, void 0, false, {
                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                lineNumber: 365,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/product/[id]/page.tsx",
                        lineNumber: 361,
                        columnNumber: 13
                    }, this) : notFound ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-center py-12",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                className: "text-lg font-medium text-gray-900 mb-2",
                                children: "Không tìm thấy sản phẩm"
                            }, void 0, false, {
                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                lineNumber: 374,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/product",
                                className: "text-yellow-500 hover:text-yellow-600 transition-colors",
                                children: "Quay lại trang sản phẩm"
                            }, void 0, false, {
                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                lineNumber: 377,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/product/[id]/page.tsx",
                        lineNumber: 373,
                        columnNumber: 13
                    }, this) : product ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "grid grid-cols-1 lg:grid-cols-2 gap-12",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative aspect-square bg-white rounded-2xl overflow-hidden",
                                                children: [
                                                    productImages[selectedImage] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        src: productImages[selectedImage],
                                                        alt: product.name,
                                                        fill: true,
                                                        className: "object-cover"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 391,
                                                        columnNumber: 23
                                                    }, this),
                                                    product.originalPrice !== undefined && product.originalPrice > product.price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "absolute top-4 left-4 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-medium",
                                                        children: [
                                                            "-",
                                                            calculateDiscount(product.originalPrice || 0, product.price),
                                                            "%"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 399,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                lineNumber: 389,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "overflow-x-auto hide-scrollbar",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex gap-4 py-2",
                                                        style: {
                                                            minWidth: 'min-content'
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>{
                                                                    console.log('Product object:', product);
                                                                    console.log('Product images array:', product.images);
                                                                    console.log('ProductImages from useMemo:', productImages);
                                                                },
                                                                className: "hidden",
                                                                children: "Debug"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 408,
                                                                columnNumber: 25
                                                            }, this),
                                                            productImages.map((image, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: ()=>setSelectedImage(index),
                                                                    className: `relative flex-shrink-0 w-24 aspect-square bg-white rounded-lg overflow-hidden ${selectedImage === index ? 'ring-2 ring-yellow-500' : ''}`,
                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                        src: image,
                                                                        alt: `${product.name} - ${index + 1}`,
                                                                        fill: true,
                                                                        className: "object-cover"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                        lineNumber: 427,
                                                                        columnNumber: 29
                                                                    }, this)
                                                                }, index, false, {
                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                    lineNumber: 420,
                                                                    columnNumber: 27
                                                                }, this))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 406,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                    lineNumber: 405,
                                                    columnNumber: 21
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                lineNumber: 404,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                        lineNumber: 388,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-8",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                        className: "text-3xl font-bold text-gray-900 mb-4",
                                                        children: product.name
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 443,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mt-6",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "space-y-2",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-baseline space-x-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "text-3xl font-bold text-yellow-500",
                                                                        children: formatPrice(product.price)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                        lineNumber: 449,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    product.originalPrice !== undefined && product.originalPrice > product.price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                        children: [
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "text-lg text-gray-700 line-through",
                                                                                children: formatPrice(product.originalPrice || 0)
                                                                            }, void 0, false, {
                                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                                lineNumber: 454,
                                                                                columnNumber: 31
                                                                            }, this),
                                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                className: "bg-yellow-100 text-yellow-600 px-2 py-1 rounded text-sm font-medium",
                                                                                children: [
                                                                                    "-",
                                                                                    calculateDiscount(product.originalPrice || 0, product.price),
                                                                                    "%"
                                                                                ]
                                                                            }, void 0, true, {
                                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                                lineNumber: 457,
                                                                                columnNumber: 31
                                                                            }, this)
                                                                        ]
                                                                    }, void 0, true)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 448,
                                                                columnNumber: 25
                                                            }, this)
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/product/[id]/page.tsx",
                                                            lineNumber: 447,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 446,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                lineNumber: 442,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-700",
                                                                children: "Thương hiệu:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 469,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-medium text-gray-900",
                                                                children: product.brand
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 470,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 468,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-700",
                                                                children: "Danh mục:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 473,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-medium text-gray-900",
                                                                children: product.category.name
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 474,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 472,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-700",
                                                                children: "Tình trạng:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 477,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: `font-medium ${(product.stock || 0) > 0 ? 'text-green-600' : 'text-red-600'}`,
                                                                children: (product.stock || 0) > 0 ? 'Còn hàng' : 'Hết hàng'
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 478,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 476,
                                                        columnNumber: 21
                                                    }, this),
                                                    (product.stock || 0) > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-gray-700",
                                                                children: "Số lượng còn lại:"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 484,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "font-medium text-gray-900",
                                                                children: product.stock
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 485,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 483,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                lineNumber: 467,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "space-y-6",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center space-x-6",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center border-2 border-gray-200 rounded-lg",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        onClick: ()=>handleQuantityChange(quantity - 1),
                                                                        className: "p-3 text-gray-700 hover:text-yellow-500 transition-colors",
                                                                        disabled: quantity <= 1,
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMinus"], {
                                                                            className: "w-4 h-4"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                            lineNumber: 498,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                        lineNumber: 493,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "w-16 text-center font-medium text-gray-900",
                                                                        children: quantity
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                        lineNumber: 500,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        onClick: ()=>handleQuantityChange(quantity + 1),
                                                                        className: "p-3 text-gray-700 hover:text-yellow-500 transition-colors",
                                                                        disabled: product.stock === undefined || product.stock <= quantity,
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiPlus"], {
                                                                            className: "w-4 h-4"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                            lineNumber: 508,
                                                                            columnNumber: 27
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                        lineNumber: 503,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 492,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                className: `p-3 rounded-full transition-all duration-300 ${inWishlist ? 'bg-primary/10 text-primary hover:bg-primary/20' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'}`,
                                                                onClick: handleToggleWishlist,
                                                                disabled: wishlistLoading,
                                                                children: wishlistLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$cg$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CgSpinner"], {
                                                                    className: "animate-spin h-5 w-5"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                    lineNumber: 521,
                                                                    columnNumber: 27
                                                                }, this) : inWishlist ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AiFillHeart"], {
                                                                    className: "h-5 w-5"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                    lineNumber: 523,
                                                                    columnNumber: 27
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$ai$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AiOutlineHeart"], {
                                                                    className: "h-5 w-5"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                    lineNumber: 525,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 511,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: handleShare,
                                                                className: "p-3 rounded-lg border-2 border-gray-200 text-gray-600 hover:text-yellow-500 hover:border-yellow-500 transition-colors",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiShare2"], {
                                                                    className: "w-6 h-6"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                    lineNumber: 532,
                                                                    columnNumber: 25
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 528,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 491,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: handleAddToCart,
                                                        className: `w-full py-5 px-8 rounded-xl flex items-center justify-center space-x-3 font-semibold text-lg ${(product.stock || 0) > 0 ? 'bg-yellow-500 text-white hover:bg-yellow-600' : 'bg-gray-300 text-gray-500 cursor-not-allowed'} transition-colors shadow-md hover:shadow-lg`,
                                                        disabled: (product.stock || 0) === 0 || addingToCart,
                                                        children: addingToCart ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$cg$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CgSpinner"], {
                                                            className: "animate-spin h-6 w-6"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/product/[id]/page.tsx",
                                                            lineNumber: 546,
                                                            columnNumber: 25
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiShoppingCart"], {
                                                                    className: "w-6 h-6"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                    lineNumber: 549,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    children: (product.stock || 0) > 0 ? 'Thêm vào giỏ hàng' : 'Hết hàng'
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                    lineNumber: 550,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 536,
                                                        columnNumber: 21
                                                    }, this),
                                                    product.specifications && product.specifications.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "mt-8",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center space-x-3 mb-6",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                                        className: "w-6 h-6 text-gray-700",
                                                                        fill: "none",
                                                                        stroke: "currentColor",
                                                                        viewBox: "0 0 24 24",
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                                            strokeLinecap: "round",
                                                                            strokeLinejoin: "round",
                                                                            strokeWidth: 2,
                                                                            d: "M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                            lineNumber: 565,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                        lineNumber: 559,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                        className: "text-xl font-bold text-gray-900",
                                                                        children: "Thông số kỹ thuật"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                        lineNumber: 572,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 558,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "divide-y divide-gray-100",
                                                                    children: product.specifications.map((spec, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                            className: `flex flex-col sm:flex-row py-4 px-6 hover:bg-gray-50 transition-colors duration-150 ${index % 2 === 0 ? 'bg-gray-50/50' : 'bg-white'}`,
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "w-full sm:w-1/3 font-medium text-gray-700 mb-2 sm:mb-0 flex items-center",
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: "inline-block",
                                                                                        children: spec.name
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                                        lineNumber: 586,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                                    lineNumber: 585,
                                                                                    columnNumber: 33
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                    className: "w-full sm:w-2/3 text-gray-700 flex items-center",
                                                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                        className: "inline-block font-normal",
                                                                                        children: spec.value
                                                                                    }, void 0, false, {
                                                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                                        lineNumber: 589,
                                                                                        columnNumber: 35
                                                                                    }, this)
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                                    lineNumber: 588,
                                                                                    columnNumber: 33
                                                                                }, this)
                                                                            ]
                                                                        }, index, true, {
                                                                            fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                            lineNumber: 579,
                                                                            columnNumber: 31
                                                                        }, this))
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                    lineNumber: 577,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                                lineNumber: 576,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                                        lineNumber: 557,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                                lineNumber: 490,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                        lineNumber: 441,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                lineNumber: 386,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-16",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        className: "text-2xl font-bold text-gray-900 mb-8",
                                        children: "Mô tả sản phẩm"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                        lineNumber: 604,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "prose prose-yellow max-w-none text-gray-800 font-medium",
                                        children: product.description
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/product/[id]/page.tsx",
                                        lineNumber: 607,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/product/[id]/page.tsx",
                                lineNumber: 603,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true) : null
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/product/[id]/page.tsx",
                lineNumber: 315,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/product/[id]/page.tsx",
            lineNumber: 314,
            columnNumber: 7
        }, this)
    }, void 0, false);
};
_s(ProductDetailPage, "JMfj6hc5VgnWmM9LiwYOMI50eEE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuth$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = ProductDetailPage;
const __TURBOPACK__default__export__ = ProductDetailPage;
var _c;
__turbopack_context__.k.register(_c, "ProductDetailPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_1d89856c._.js.map