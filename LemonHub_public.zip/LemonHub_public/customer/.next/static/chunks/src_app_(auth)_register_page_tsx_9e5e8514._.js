(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(auth)_register_page_tsx_9e5e8514._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(auth)_register_page_tsx_9e5e8514._.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7f5._.js",
    "static/chunks/node_modules_react-icons_fc_index_mjs_3f3027b2._.js",
    "static/chunks/src_app_(auth)_register_page_tsx_0b0f3022._.js"
  ],
  "source": "dynamic"
});
