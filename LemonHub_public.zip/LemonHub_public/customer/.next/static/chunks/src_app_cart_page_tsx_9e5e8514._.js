(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_cart_page_tsx_9e5e8514._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_cart_page_tsx_9e5e8514._.js",
  "chunks": [
    "static/chunks/node_modules_next_15251bc2._.js",
    "static/chunks/src_94e80ad6._.js"
  ],
  "source": "dynamic"
});
