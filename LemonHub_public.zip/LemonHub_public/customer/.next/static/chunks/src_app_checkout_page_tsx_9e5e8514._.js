(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_checkout_page_tsx_9e5e8514._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_checkout_page_tsx_9e5e8514._.js",
  "chunks": [
    "static/chunks/src_7d1ddae3._.js",
    "static/chunks/node_modules_next_15251bc2._.js",
    "static/chunks/src_app_checkout_checkout_72c0cd1d.css"
  ],
  "source": "dynamic"
});
