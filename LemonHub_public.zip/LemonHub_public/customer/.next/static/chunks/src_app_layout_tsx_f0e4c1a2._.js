(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/[root of the server]__08514339._.css",
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_0bbe6469._.js",
    "static/chunks/src_0267529e._.js",
    "static/chunks/node_modules_react-icons_fi_index_mjs_9cbf4bb1._.js",
    "static/chunks/node_modules_react-icons_bi_index_mjs_cba0e860._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc930._.js",
    "static/chunks/node_modules_axios_lib_99999129._.js",
    "static/chunks/node_modules_5446dac3._.js"
  ],
  "source": "dynamic"
});
