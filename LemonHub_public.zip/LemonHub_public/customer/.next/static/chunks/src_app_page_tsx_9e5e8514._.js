(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_9e5e8514._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_9e5e8514._.js",
  "chunks": [
    "static/chunks/node_modules_e8dd0ef1._.js",
    "static/chunks/src_997586bb._.js"
  ],
  "source": "dynamic"
});
