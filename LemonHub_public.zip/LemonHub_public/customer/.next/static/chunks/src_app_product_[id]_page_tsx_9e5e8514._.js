(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_product_[id]_page_tsx_9e5e8514._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_product_[id]_page_tsx_9e5e8514._.js",
  "chunks": [
    "static/chunks/src_1d89856c._.js",
    "static/chunks/node_modules_next_15251bc2._.js",
    "static/chunks/node_modules_react-icons_ai_index_mjs_b8cfc3ce._.js",
    "static/chunks/node_modules_react-icons_cg_index_mjs_1c0b6008._.js"
  ],
  "source": "dynamic"
});
