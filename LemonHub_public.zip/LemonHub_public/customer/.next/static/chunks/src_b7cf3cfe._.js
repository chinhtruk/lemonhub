(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_b7cf3cfe._.js", {

"[project]/src/services/user.service.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "addAddress": (()=>addAddress),
    "addPaymentMethod": (()=>addPaymentMethod),
    "addToWishlist": (()=>addToWishlist),
    "changePassword": (()=>changePassword),
    "checkWishlist": (()=>checkWishlist),
    "deleteAddress": (()=>deleteAddress),
    "deletePaymentMethod": (()=>deletePaymentMethod),
    "getCurrentUser": (()=>getCurrentUser),
    "getUserAddresses": (()=>getUserAddresses),
    "getUserOrders": (()=>getUserOrders),
    "getUserPaymentMethods": (()=>getUserPaymentMethods),
    "getUserWishlist": (()=>getUserWishlist),
    "removeFromWishlist": (()=>removeFromWishlist),
    "setDefaultAddress": (()=>setDefaultAddress),
    "setDefaultPaymentMethod": (()=>setDefaultPaymentMethod),
    "updateAddress": (()=>updateAddress),
    "updatePaymentMethod": (()=>updatePaymentMethod),
    "updateUserProfile": (()=>updateUserProfile),
    "uploadAvatar": (()=>uploadAvatar)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/api.js [app-client] (ecmascript)");
;
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:5001';
const getCurrentUser = async ()=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/users/profile');
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể tải thông tin người dùng';
    }
};
const updateUserProfile = async (userData)=>{
    try {
        // Ensure we're sending all the required fields
        const dataToUpdate = {
            name: userData.name,
            email: userData.email,
            phone: userData.phone,
            address: userData.address,
            birthday: userData.birthday,
            gender: userData.gender
        };
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put('/users/profile', dataToUpdate);
        // Return the updated user data from the server
        return data;
    } catch (error) {
        console.error('Error updating profile:', error);
        throw error.response?.data?.message || 'Không thể cập nhật thông tin người dùng';
    }
};
const getUserOrders = async ()=>{
    try {
        console.log('Calling API to get user orders');
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/orders/myorders');
        console.log('Orders API response:', data);
        // Transform orders data để phù hợp với các yêu cầu hiển thị
        const formattedOrders = data.map((order)=>{
            return {
                id: order._id,
                date: order.createdAt,
                total: order.totalPrice,
                status: order.status || 'pending',
                trackingCode: order.trackingCode,
                items: order.orderItems.map((item)=>({
                        id: item._id,
                        name: item.name,
                        image: item.image,
                        price: item.price,
                        quantity: item.qty
                    }))
            };
        });
        console.log('Formatted orders for frontend:', formattedOrders);
        return formattedOrders;
    } catch (error) {
        console.error('Error fetching orders:', error.response?.data || error.message);
        throw error.response?.data?.message || 'Không thể tải danh sách đơn hàng';
    }
};
const getUserWishlist = async ()=>{
    try {
        console.log('Fetching user wishlist');
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get('/users/wishlist');
        // Kiểm tra dữ liệu trả về
        if (!data) {
            console.warn('No wishlist data returned from API');
            return [];
        }
        // Đảm bảo dữ liệu trả về là một mảng
        if (!Array.isArray(data)) {
            console.warn('Wishlist data is not an array:', data);
            return [];
        }
        // Log detailed wishlist data for debugging
        console.log('Raw wishlist data from API:', JSON.stringify(data));
        // Ensure each product has the correct image path
        const processedData = data.map((product)=>{
            // Force log every product to debug
            console.log('Processing wishlist product:', JSON.stringify(product));
            // Fix missing or empty image
            if (!product.image || product.image === '') {
                console.warn('Product without image:', product.id || product._id);
                return {
                    ...product,
                    image: '/images/product-placeholder.svg'
                };
            }
            // Complete image URLs if they're relative paths
            let imageUrl = product.image;
            if (imageUrl && !imageUrl.startsWith('http') && !imageUrl.startsWith('/')) {
                imageUrl = `/${imageUrl}`;
            }
            if (imageUrl && !imageUrl.startsWith('http') && imageUrl.startsWith('/')) {
                imageUrl = `${API_URL}${imageUrl}`;
            }
            return {
                ...product,
                image: imageUrl
            };
        });
        console.log('Wishlist loaded successfully:', processedData.length, 'items');
        console.log('Processed wishlist items IDs:', processedData.map((item)=>item.id || item._id));
        return processedData;
    } catch (error) {
        console.error('Error fetching wishlist:', error);
        console.error('Error details:', error.response?.data || error.message);
        // Check if it's an authentication error
        if (error.response?.status === 401) {
            console.warn('Authentication error when fetching wishlist - token may be invalid');
        }
        // Return empty array instead of throwing error to prevent UI failures
        return [];
    }
};
const addToWishlist = async (productId)=>{
    try {
        console.log('Adding product to wishlist:', productId);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/users/wishlist', {
            productId
        });
        if (data.success) {
            console.log('Product added to wishlist successfully');
        }
        return data;
    } catch (error) {
        console.error('Error adding to wishlist:', error.response?.data || error);
        throw error.response?.data?.message || 'Không thể thêm sản phẩm vào danh sách yêu thích';
    }
};
const removeFromWishlist = async (productId)=>{
    try {
        console.log('Removing product from wishlist:', productId);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`/users/wishlist/${productId}`);
        if (data.success) {
            console.log('Product removed from wishlist successfully');
        }
        return data;
    } catch (error) {
        console.error('Error removing from wishlist:', error.response?.data || error);
        throw error.response?.data?.message || 'Không thể xóa sản phẩm khỏi danh sách yêu thích';
    }
};
const checkWishlist = async (productId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`/users/wishlist/${productId}`);
        return data.inWishlist;
    } catch (error) {
        console.error('Error checking wishlist status:', error);
        return false;
    }
};
const getUserAddresses = async (forceReload = false)=>{
    try {
        console.log('Đang tải danh sách địa chỉ', forceReload ? '(bắt buộc tải mới)' : '');
        // Tạo URL endpoing chính xác 
        const endpoint = '/users/addresses';
        console.log(`Gửi yêu cầu API đến: ${endpoint}`);
        // Lấy dữ liệu từ API server
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(endpoint);
        // Ghi log thông tin chi tiết dữ liệu trả về
        console.log('Dữ liệu địa chỉ gốc từ server (raw):', JSON.stringify(data));
        // Kiểm tra dữ liệu trả về
        if (!data) {
            console.warn('Không có dữ liệu địa chỉ trả về từ API');
            return [];
        }
        // Đảm bảo dữ liệu trả về là một mảng
        if (!Array.isArray(data)) {
            console.warn('Dữ liệu địa chỉ không phải là mảng:', typeof data, data);
            // Nếu là object có thuộc tính addresses là mảng, trả về addresses
            if (data && typeof data === 'object' && Array.isArray(data.addresses)) {
                console.log('Nhận dạng format response có field addresses, sử dụng data.addresses');
                return data.addresses;
            }
            return [];
        }
        console.log('Đã tải thành công', data.length, 'địa chỉ từ server');
        // Kiểm tra và log từng địa chỉ trong mảng
        data.forEach((address, index)=>{
            console.log(`Địa chỉ #${index + 1}:`, JSON.stringify(address));
            // Kiểm tra xem mỗi địa chỉ có thuộc tính id không, nếu không thì dùng _id
            if (!address.id && address._id) {
                console.log(`Chuyển đổi _id thành id cho địa chỉ #${index + 1}`);
                address.id = address._id;
            }
        });
        // Đảm bảo mỗi địa chỉ đều có thuộc tính id và các thuộc tính cần thiết
        const processedAddresses = data.map((address)=>{
            // Đảm bảo các trường cần thiết đều có
            return {
                id: address.id || address._id || 'unknown-id',
                fullName: address.fullName || 'Không có tên',
                phone: address.phone || 'Không có SĐT',
                address: address.address || 'Không có địa chỉ',
                isDefault: !!address.isDefault
            };
        });
        console.log('Địa chỉ sau khi xử lý:', JSON.stringify(processedAddresses));
        // Cập nhật localStorage
        try {
            const userInfoStr = localStorage.getItem('userInfo');
            if (userInfoStr) {
                const userInfo = JSON.parse(userInfoStr);
                if (userInfo && userInfo._id) {
                    userInfo.addresses = processedAddresses;
                    localStorage.setItem('userInfo', JSON.stringify(userInfo));
                    console.log('Đã cập nhật địa chỉ trong localStorage từ phản hồi API');
                }
            }
        } catch (e) {
            console.warn('Không thể cập nhật địa chỉ trong localStorage:', e);
        }
        return processedAddresses;
    } catch (error) {
        console.error('Lỗi khi tải địa chỉ:', error);
        console.error('Chi tiết lỗi:', error.response?.data || error.message);
        console.error('Config URL:', error.config?.url);
        console.error('Request headers:', error.config?.headers);
        // Kiểm tra nếu là lỗi xác thực
        if (error.response?.status === 401) {
            console.warn('Lỗi xác thực khi tải địa chỉ - token có thể không hợp lệ');
        }
        // Trả về mảng rỗng thay vì ném lỗi để tránh lỗi giao diện
        return [];
    }
};
const addAddress = async (addressData)=>{
    try {
        console.log('Adding new address:', addressData);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/users/addresses', addressData);
        console.log('Address added successfully:', data);
        // Update addresses in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id) {
                if (!Array.isArray(userInfo.addresses)) {
                    userInfo.addresses = [];
                }
                userInfo.addresses.push(data);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with new address');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with new address:', localStorageError);
        }
        return data;
    } catch (error) {
        console.error('Error adding address:', error);
        throw error.response?.data?.message || 'Không thể thêm địa chỉ mới';
    }
};
const updateAddress = async (addressId, addressData)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/users/addresses/${addressId}`, addressData);
        // Update addresses in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.addresses)) {
                userInfo.addresses = userInfo.addresses.map((addr)=>addr.id === addressId ? {
                        ...addr,
                        ...data
                    } : addr);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with updated address');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with updated address:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể cập nhật địa chỉ';
    }
};
const deleteAddress = async (addressId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`/users/addresses/${addressId}`);
        // Update addresses in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.addresses)) {
                userInfo.addresses = userInfo.addresses.filter((addr)=>addr.id !== addressId);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage after removing address');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage after removing address:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể xóa địa chỉ';
    }
};
const setDefaultAddress = async (addressId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/users/addresses/${addressId}/default`);
        // Update addresses in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.addresses)) {
                userInfo.addresses = userInfo.addresses.map((addr)=>({
                        ...addr,
                        isDefault: addr.id === addressId
                    }));
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with default address change');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with default address change:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể đặt địa chỉ mặc định';
    }
};
const changePassword = async (passwordData)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put('/users/change-password', passwordData);
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể thay đổi mật khẩu';
    }
};
const uploadAvatar = async (file)=>{
    try {
        console.log('User service: Uploading avatar file', file.name, 'size:', file.size);
        const formData = new FormData();
        formData.append('avatar', file);
        // Gọi API để upload avatar
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/users/upload-avatar', formData, {
            headers: {
                'Content-Type': 'multipart/form-data'
            }
        });
        console.log('Upload avatar API response:', response.data);
        // Check if the response has the avatar path
        if (!response.data || !response.data.avatarUrl) {
            console.error('Avatar path not found in API response:', response.data);
            throw new Error('Avatar path not found in response');
        }
        let avatarUrl = response.data.avatarUrl;
        // Ensure the avatar URL is complete
        if (!avatarUrl.startsWith('http') && !avatarUrl.startsWith('/')) {
            avatarUrl = `/${avatarUrl}`;
        }
        if (!avatarUrl.startsWith('http') && avatarUrl.startsWith('/')) {
            avatarUrl = `${API_URL}${avatarUrl}`;
        }
        // Add a timestamp to prevent caching
        const timestamp = Date.now();
        avatarUrl = avatarUrl.includes('?') ? `${avatarUrl}&t=${timestamp}` : `${avatarUrl}?t=${timestamp}`;
        console.log('Final avatar URL with cache busting:', avatarUrl);
        // Update the user profile in the session storage
        const user = JSON.parse(sessionStorage.getItem('user') || '{}');
        user.avatar = avatarUrl;
        sessionStorage.setItem('user', JSON.stringify(user));
        // Return the updated user with the avatar URL
        return {
            ...response.data,
            avatar: avatarUrl
        };
    } catch (error) {
        console.error('Error uploading avatar:', error);
        throw error;
    }
};
const getUserPaymentMethods = async ()=>{
    try {
        console.log('Đang tải phương thức thanh toán');
        // Tạo URL endpoint chính xác
        const endpoint = '/users/payment-methods';
        console.log(`Gửi yêu cầu API đến: ${endpoint}`);
        // Lấy dữ liệu từ API server
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(endpoint);
        // Ghi log thông tin chi tiết dữ liệu trả về
        console.log('Dữ liệu phương thức thanh toán từ server (raw):', JSON.stringify(data));
        // Kiểm tra dữ liệu trả về
        if (!data) {
            console.warn('Không có dữ liệu phương thức thanh toán trả về từ API');
            return [];
        }
        // Đảm bảo dữ liệu trả về là một mảng
        if (!Array.isArray(data)) {
            console.warn('Dữ liệu phương thức thanh toán không phải là mảng:', typeof data, data);
            // Nếu là object có thuộc tính paymentMethods là mảng, trả về paymentMethods
            if (data && typeof data === 'object' && Array.isArray(data.paymentMethods)) {
                console.log('Nhận dạng format response có field paymentMethods, sử dụng data.paymentMethods');
                return data.paymentMethods;
            }
            return [];
        }
        console.log('Đã tải thành công', data.length, 'phương thức thanh toán từ server');
        // Kiểm tra và đảm bảo mỗi phương thức thanh toán đều có thuộc tính id
        const processedPaymentMethods = data.map((method, index)=>{
            console.log(`Phương thức thanh toán #${index + 1}:`, JSON.stringify(method));
            // Chuyển đổi _id thành id nếu cần
            if (!method.id && method._id) {
                console.log(`Chuyển đổi _id thành id cho phương thức thanh toán #${index + 1}`);
                method.id = method._id;
            }
            // Đảm bảo các trường cần thiết đều có
            return {
                id: method.id || method._id || 'unknown-id',
                type: method.type || 'unknown',
                cardNumber: method.cardNumber || '',
                expiryDate: method.expiryDate || '',
                isDefault: !!method.isDefault,
                bankName: method.bankName || '',
                cardType: method.cardType || ''
            };
        });
        console.log('Phương thức thanh toán sau khi xử lý:', JSON.stringify(processedPaymentMethods));
        // Cập nhật localStorage
        try {
            const userInfoStr = localStorage.getItem('userInfo');
            if (userInfoStr) {
                const userInfo = JSON.parse(userInfoStr);
                if (userInfo && userInfo._id) {
                    userInfo.paymentMethods = processedPaymentMethods;
                    localStorage.setItem('userInfo', JSON.stringify(userInfo));
                    console.log('Đã cập nhật phương thức thanh toán trong localStorage từ phản hồi API');
                }
            }
        } catch (e) {
            console.warn('Không thể cập nhật phương thức thanh toán trong localStorage:', e);
        }
        return processedPaymentMethods;
    } catch (error) {
        console.error('Lỗi khi tải phương thức thanh toán:', error);
        console.error('Chi tiết lỗi:', error.response?.data || error.message);
        console.error('Config URL:', error.config?.url);
        console.error('Request headers:', error.config?.headers);
        // Kiểm tra nếu là lỗi xác thực
        if (error.response?.status === 401) {
            console.warn('Lỗi xác thực khi tải phương thức thanh toán - token có thể không hợp lệ');
        }
        // Trả về mảng rỗng thay vì ném lỗi để tránh lỗi giao diện
        return [];
    }
};
const addPaymentMethod = async (paymentData)=>{
    try {
        console.log('Adding new payment method:', paymentData);
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post('/users/payment-methods', paymentData);
        console.log('Payment method added successfully:', data);
        // Update payment methods in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id) {
                if (!Array.isArray(userInfo.paymentMethods)) {
                    userInfo.paymentMethods = [];
                }
                userInfo.paymentMethods.push(data);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with new payment method');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with new payment method:', localStorageError);
        }
        return data;
    } catch (error) {
        console.error('Error adding payment method:', error);
        throw error.response?.data?.message || 'Không thể thêm phương thức thanh toán mới';
    }
};
const updatePaymentMethod = async (paymentId, paymentData)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/users/payment-methods/${paymentId}`, paymentData);
        // Update payment methods in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.paymentMethods)) {
                userInfo.paymentMethods = userInfo.paymentMethods.map((method)=>method.id === paymentId ? {
                        ...method,
                        ...data
                    } : method);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with updated payment method');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with updated payment method:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể cập nhật phương thức thanh toán';
    }
};
const deletePaymentMethod = async (paymentId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].delete(`/users/payment-methods/${paymentId}`);
        // Update payment methods in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.paymentMethods)) {
                userInfo.paymentMethods = userInfo.paymentMethods.filter((method)=>method.id !== paymentId);
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage after removing payment method');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage after removing payment method:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể xóa phương thức thanh toán';
    }
};
const setDefaultPaymentMethod = async (paymentId)=>{
    try {
        const { data } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$api$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].put(`/users/payment-methods/${paymentId}/default`);
        // Update payment methods in userInfo localStorage
        try {
            const userInfo = JSON.parse(localStorage.getItem('userInfo') || '{}');
            if (userInfo && userInfo._id && Array.isArray(userInfo.paymentMethods)) {
                userInfo.paymentMethods = userInfo.paymentMethods.map((method)=>({
                        ...method,
                        isDefault: method.id === paymentId
                    }));
                localStorage.setItem('userInfo', JSON.stringify(userInfo));
                console.log('Updated userInfo in localStorage with default payment method change');
            }
        } catch (localStorageError) {
            console.error('Error updating localStorage with default payment method change:', localStorageError);
        }
        return data;
    } catch (error) {
        throw error.response?.data?.message || 'Không thể đặt phương thức thanh toán mặc định';
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/UserAvatar.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>__TURBOPACK__default__export__)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
// Get the API URL from environment variable or use default
const API_URL = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_API_URL || 'http://localhost:5001';
const UserAvatar = ({ name, avatar, size = 96, onChangeAvatar, className = '' })=>{
    _s();
    const [showOptions, setShowOptions] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [viewImage, setViewImage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [timestamp, setTimestamp] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(Date.now()); // Add timestamp for cache busting
    const optionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const fileInputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Function to get the full image URL with cache busting
    const getImageUrl = (src)=>{
        if (!src) return '';
        // Add timestamp for cache busting
        const cacheBuster = `?t=${timestamp}`;
        // If it's already an absolute URL, use it as is
        if (src.startsWith('http')) return `${src}${cacheBuster}`;
        // If it's a server path starting with /uploads, prepend the API URL
        if (src.startsWith('/uploads')) return `${API_URL}${src}${cacheBuster}`;
        // Otherwise, return as is with cache buster
        return `${src}${cacheBuster}`;
    };
    // Update timestamp when avatar changes to force reload
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UserAvatar.useEffect": ()=>{
            setTimestamp(Date.now());
        }
    }["UserAvatar.useEffect"], [
        avatar
    ]);
    // Generate initials from name
    const getInitials = ()=>{
        if (!name) return '?';
        return name.split(' ').map((part)=>part[0]).join('').toUpperCase().substring(0, 2);
    };
    // Generate a color based on name
    const getColor = ()=>{
        if (!name) return '#6366F1'; // Default indigo color
        // List of pastel/soft colors
        const colors = [
            '#F87171',
            '#FB923C',
            '#FBBF24',
            '#A3E635',
            '#34D399',
            '#22D3EE',
            '#60A5FA',
            '#818CF8',
            '#A78BFA',
            '#E879F9',
            '#F472B6'
        ];
        // Use the sum of the character codes to generate a consistent index
        const charCodeSum = name.split('').reduce((sum, char)=>sum + char.charCodeAt(0), 0);
        return colors[charCodeSum % colors.length];
    };
    // Handle file input change
    const handleFileChange = (e)=>{
        const file = e.target.files?.[0];
        if (file && onChangeAvatar) {
            onChangeAvatar(file);
            setShowOptions(false);
            // Update timestamp to ensure image reload
            setTimestamp(Date.now());
        }
    };
    // Handle outside click to close options menu
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UserAvatar.useEffect": ()=>{
            const handleOutsideClick = {
                "UserAvatar.useEffect.handleOutsideClick": (e)=>{
                    if (optionsRef.current && !optionsRef.current.contains(e.target)) {
                        setShowOptions(false);
                    }
                }
            }["UserAvatar.useEffect.handleOutsideClick"];
            if (showOptions) {
                document.addEventListener('mousedown', handleOutsideClick);
            }
            return ({
                "UserAvatar.useEffect": ()=>{
                    document.removeEventListener('mousedown', handleOutsideClick);
                }
            })["UserAvatar.useEffect"];
        }
    }["UserAvatar.useEffect"], [
        showOptions
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `relative ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative cursor-pointer rounded-full overflow-hidden",
                style: {
                    width: size,
                    height: size
                },
                onClick: ()=>setShowOptions(true),
                children: avatar ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: getImageUrl(avatar),
                    alt: name || 'User',
                    fill: true,
                    className: "object-cover",
                    priority: true,
                    unoptimized: true
                }, void 0, false, {
                    fileName: "[project]/src/components/UserAvatar.tsx",
                    lineNumber: 123,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full h-full flex items-center justify-center text-white font-medium",
                    style: {
                        backgroundColor: getColor(),
                        fontSize: size * 0.4
                    },
                    children: getInitials()
                }, void 0, false, {
                    fileName: "[project]/src/components/UserAvatar.tsx",
                    lineNumber: 132,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/UserAvatar.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            showOptions && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: optionsRef,
                className: "absolute z-10 mt-2 bg-white rounded-lg shadow-lg py-2 w-48",
                style: {
                    top: size,
                    left: '50%',
                    transform: 'translateX(-50%)'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "w-full px-4 py-2 text-left flex items-center hover:bg-gray-100",
                        onClick: ()=>{
                            setViewImage(true);
                            setShowOptions(false);
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEye"], {
                                className: "mr-2"
                            }, void 0, false, {
                                fileName: "[project]/src/components/UserAvatar.tsx",
                                lineNumber: 155,
                                columnNumber: 13
                            }, this),
                            "Xem ảnh đại diện"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/UserAvatar.tsx",
                        lineNumber: 148,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "w-full px-4 py-2 text-left flex items-center hover:bg-gray-100",
                        onClick: ()=>fileInputRef.current?.click(),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiCamera"], {
                                className: "mr-2"
                            }, void 0, false, {
                                fileName: "[project]/src/components/UserAvatar.tsx",
                                lineNumber: 162,
                                columnNumber: 13
                            }, this),
                            "Đổi ảnh đại diện"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/UserAvatar.tsx",
                        lineNumber: 158,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: fileInputRef,
                        type: "file",
                        className: "hidden",
                        accept: "image/*",
                        onChange: handleFileChange
                    }, void 0, false, {
                        fileName: "[project]/src/components/UserAvatar.tsx",
                        lineNumber: 165,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/UserAvatar.tsx",
                lineNumber: 143,
                columnNumber: 9
            }, this),
            viewImage && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 bg-black bg-opacity-80 flex items-center justify-center",
                onClick: ()=>setViewImage(false),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative max-w-4xl max-h-[90vh]",
                    children: avatar ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: getImageUrl(avatar),
                        alt: name || 'User',
                        width: 800,
                        height: 800,
                        className: "object-contain",
                        unoptimized: true
                    }, void 0, false, {
                        fileName: "[project]/src/components/UserAvatar.tsx",
                        lineNumber: 183,
                        columnNumber: 15
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-96 h-96 flex items-center justify-center text-white font-bold rounded-full",
                        style: {
                            backgroundColor: getColor(),
                            fontSize: 120
                        },
                        children: getInitials()
                    }, void 0, false, {
                        fileName: "[project]/src/components/UserAvatar.tsx",
                        lineNumber: 192,
                        columnNumber: 15
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/UserAvatar.tsx",
                    lineNumber: 181,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/UserAvatar.tsx",
                lineNumber: 177,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/UserAvatar.tsx",
        lineNumber: 115,
        columnNumber: 5
    }, this);
};
_s(UserAvatar, "+WToXzlWWGdEcCKmljPbK4blSHI=");
_c = UserAvatar;
const __TURBOPACK__default__export__ = UserAvatar;
var _c;
__turbopack_context__.k.register(_c, "UserAvatar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/profile/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ProfilePage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hot-toast/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$user$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/user.service.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$auth$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/services/auth.service.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UserAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/UserAvatar.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
const formatDate = (dateString)=>{
    if (!dateString) return 'N/A';
    try {
        return new Date(dateString).toLocaleDateString('vi-VN', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
    } catch (e) {
        console.error('Invalid date format:', dateString);
        return 'N/A';
    }
};
function ProfilePage() {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        email: '',
        phone: '',
        avatar: '/images/avatar-placeholder.svg',
        address: '',
        wishlist: [],
        birthday: '',
        gender: 'male',
        orders: []
    });
    const [editedUser, setEditedUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        name: '',
        email: '',
        phone: '',
        avatar: '/images/avatar-placeholder.svg',
        address: '',
        wishlist: [],
        birthday: '',
        gender: 'male',
        orders: []
    });
    const [isEditing, setIsEditing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [isLoggedIn, setIsLoggedIn] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true); // Track login state
    // Thêm state cho phần đổi mật khẩu
    const [isChangingPassword, setIsChangingPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [passwordData, setPasswordData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
    });
    const [passwordError, setPasswordError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    // Tải thông tin người dùng khi component mount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ProfilePage.useEffect": ()=>{
            const fetchUserData = {
                "ProfilePage.useEffect.fetchUserData": async ()=>{
                    try {
                        setLoading(true);
                        // Kiểm tra nếu localStorage có userInfo
                        const userInfoStr = localStorage.getItem('userInfo');
                        if (!userInfoStr) {
                            console.warn('No userInfo found in localStorage');
                            setIsLoggedIn(false);
                            setError('Vui lòng đăng nhập để xem thông tin cá nhân');
                            setLoading(false);
                            return;
                        }
                        // Giải mã token và kiểm tra tính hợp lệ cơ bản
                        try {
                            const userInfo = JSON.parse(userInfoStr);
                            if (!userInfo || !userInfo.token) {
                                console.warn('Invalid userInfo or missing token');
                                setIsLoggedIn(false);
                                setError('Phiên đăng nhập không hợp lệ. Vui lòng đăng nhập lại.');
                                setLoading(false);
                                return;
                            }
                        } catch (e) {
                            console.error('Error parsing userInfo:', e);
                            setIsLoggedIn(false);
                            setError('Phiên đăng nhập không hợp lệ. Vui lòng đăng nhập lại.');
                            setLoading(false);
                            return;
                        }
                        // Gọi API để lấy thông tin user
                        const userData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$user$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCurrentUser"])();
                        if (!userData || !userData.email) {
                            console.error('Invalid user data or user not logged in:', userData);
                            setIsLoggedIn(false);
                            setError('Vui lòng đăng nhập để xem thông tin cá nhân');
                            return;
                        }
                        console.log('User data loaded successfully:', userData);
                        // Đảm bảo tất cả các mảng tồn tại
                        const safeUserData = {
                            ...userData,
                            orders: userData.orders || [],
                            wishlist: userData.wishlist || []
                        };
                        setUser(safeUserData);
                        setEditedUser(safeUserData);
                        setIsLoggedIn(true);
                    } catch (err) {
                        console.error('Error fetching user data:', err);
                        // Kiểm tra lỗi chi tiết hơn
                        let errorMessage = 'Không thể tải thông tin người dùng. Vui lòng thử lại sau.';
                        let isAuthError = false;
                        // Kiểm tra lỗi 401 Unauthorized
                        if (err && typeof err === 'object') {
                            // Kiểm tra lỗi từ Axios
                            if ('response' in err && err.response && typeof err.response === 'object' && 'status' in err.response && err.response.status === 401) {
                                errorMessage = 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.';
                                isAuthError = true;
                            } else if ('details' in err && err.details && typeof err.details === 'object' && 'status' in err.details && err.details.status === 401) {
                                errorMessage = 'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.';
                                isAuthError = true;
                            } else if ('message' in err && typeof err.message === 'string' && (err.message.includes('phiên') || err.message.includes('đăng nhập') || err.message.includes('xác thực') || err.message.toLowerCase().includes('auth'))) {
                                errorMessage = err.message;
                                isAuthError = true;
                            }
                        }
                        // Đặt trạng thái lỗi và hiển thị cho người dùng
                        setError(errorMessage);
                        setIsLoggedIn(!isAuthError); // Chỉ đặt isLoggedIn = false nếu lỗi xác thực
                        // Hiển thị thông báo lỗi bằng toast
                        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(errorMessage);
                    // Không tự động xóa userInfo, để người dùng có cơ hội thử lại hoặc đăng nhập lại bằng nút
                    } finally{
                        setLoading(false);
                    }
                }
            }["ProfilePage.useEffect.fetchUserData"];
            // Kiểm tra session storage cho auth_warning
            const checkAuthWarning = {
                "ProfilePage.useEffect.checkAuthWarning": ()=>{
                    if ("TURBOPACK compile-time truthy", 1) {
                        const authWarning = sessionStorage.getItem('auth_warning');
                        if (authWarning === 'true') {
                            // Xóa cảnh báo
                            sessionStorage.removeItem('auth_warning');
                            // Hiển thị toast để người dùng biết
                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Phiên đăng nhập có thể đã hết hạn. Hãy thử đăng nhập lại nếu gặp vấn đề.');
                        }
                    }
                }
            }["ProfilePage.useEffect.checkAuthWarning"];
            fetchUserData();
            checkAuthWarning();
        }
    }["ProfilePage.useEffect"], []);
    const handleSaveProfile = async ()=>{
        try {
            setLoading(true);
            // Make a deep copy of the editedUser to ensure we're not mutating the original state
            const userToUpdate = {
                ...editedUser
            };
            // Call the API to update the user profile
            const updatedUser = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$user$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateUserProfile"])(userToUpdate);
            // Update the local state with the response from the server
            setUser((prevUser)=>({
                    ...prevUser,
                    ...updatedUser
                }));
            setIsEditing(false);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Cập nhật thông tin thành công');
        } catch (err) {
            console.error('Error updating profile:', err);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Không thể cập nhật thông tin. Vui lòng thử lại.');
        } finally{
            setLoading(false);
        }
    };
    const handleCancelEdit = ()=>{
        setEditedUser(user);
        setIsEditing(false);
    };
    // Xử lý đổi mật khẩu
    const handleChangePassword = async (e)=>{
        e.preventDefault();
        setPasswordError('');
        if (passwordData.newPassword !== passwordData.confirmPassword) {
            setPasswordError('Mật khẩu mới không khớp với xác nhận mật khẩu');
            return;
        }
        if (passwordData.newPassword.length < 6) {
            setPasswordError('Mật khẩu mới phải có ít nhất 6 ký tự');
            return;
        }
        try {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$services$2f$auth$2e$service$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["changePassword"])({
                currentPassword: passwordData.currentPassword,
                newPassword: passwordData.newPassword
            });
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Đổi mật khẩu thành công');
            setPasswordData({
                currentPassword: '',
                newPassword: '',
                confirmPassword: ''
            });
            setIsChangingPassword(false);
        } catch (err) {
            console.error('Change password error:', err);
            setPasswordError(err.message || 'Đổi mật khẩu thất bại. Vui lòng thử lại.');
        }
    };
    // Set user avatar
    const handleAvatarUpload = async (file)=>{
        if (!file) return;
        // Check file type
        const fileType = file.type;
        if (!fileType.includes('image')) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Chỉ chấp nhận tệp hình ảnh');
            return;
        }
        // Check file size (max 2MB)
        const fileSize = file.size / 1024 / 1024; // in MB
        if (fileSize > 2) {
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error('Kích thước tệp không được vượt quá 2MB');
            return;
        }
        try {
            setLoading(true);
            // Create form data
            const formData = new FormData();
            formData.append('avatar', file);
            // Upload avatar
            const response = await fetch('/api/users/avatar', {
                method: 'POST',
                body: formData
            });
            if (!response.ok) {
                throw new Error('Không thể tải lên ảnh đại diện');
            }
            const data = await response.json();
            // Update user state
            setUser((prev)=>({
                    ...prev,
                    avatar: data.avatar
                }));
            // Update local storage
            try {
                const userInfoStr = localStorage.getItem('userInfo');
                if (userInfoStr) {
                    const userInfo = JSON.parse(userInfoStr);
                    if (userInfo && typeof userInfo === 'object') {
                        userInfo.avatar = data.avatar;
                        localStorage.setItem('userInfo', JSON.stringify(userInfo));
                    }
                }
            } catch (error) {
                console.error('Lỗi khi cập nhật avatar trong localStorage:', error);
            }
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].success('Đã cập nhật ảnh đại diện');
        } catch (error) {
            console.error('Lỗi khi tải lên avatar:', error);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toast"].error(error instanceof Error ? error.message : 'Không thể tải lên ảnh đại diện');
        } finally{
            setLoading(false);
        }
    };
    // safeUser object to prevent UI errors when properties might be undefined
    const safeUser = {
        ...user,
        wishlist: Array.isArray(user.wishlist) ? user.wishlist : [],
        orders: Array.isArray(user.orders) ? user.orders : []
    };
    // Render UI dựa trên trạng thái
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-gray-50 p-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center min-h-screen",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "text-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-yellow-500 mx-auto"
                        }, void 0, false, {
                            fileName: "[project]/src/app/profile/page.tsx",
                            lineNumber: 351,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-4 text-gray-600",
                            children: "Đang tải..."
                        }, void 0, false, {
                            fileName: "[project]/src/app/profile/page.tsx",
                            lineNumber: 352,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/profile/page.tsx",
                    lineNumber: 350,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/profile/page.tsx",
                lineNumber: 349,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/profile/page.tsx",
            lineNumber: 348,
            columnNumber: 7
        }, this);
    }
    // Hiển thị trạng thái lỗi khi chưa đăng nhập
    if (!isLoggedIn || error) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-gray-50 p-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center min-h-screen",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "max-w-md w-full bg-white p-8 rounded-2xl shadow-sm",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-center mb-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUser"], {
                                    className: "text-yellow-500 mx-auto w-16 h-16"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/profile/page.tsx",
                                    lineNumber: 366,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "text-2xl font-bold mt-4 text-gray-900",
                                    children: "Thông tin cá nhân"
                                }, void 0, false, {
                                    fileName: "[project]/src/app/profile/page.tsx",
                                    lineNumber: 367,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-2 text-red-500",
                                    children: error
                                }, void 0, false, {
                                    fileName: "[project]/src/app/profile/page.tsx",
                                    lineNumber: 370,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/profile/page.tsx",
                            lineNumber: 365,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>window.location.href = '/login',
                                    className: "w-full bg-yellow-500 text-white py-3 rounded-xl font-medium hover:bg-yellow-600 transition-colors flex items-center justify-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiLogOut"], {
                                            className: "mr-2"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/profile/page.tsx",
                                            lineNumber: 378,
                                            columnNumber: 17
                                        }, this),
                                        " Đăng nhập"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/profile/page.tsx",
                                    lineNumber: 374,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: ()=>{
                                        // Cố gắng tải lại dữ liệu mà không chuyển hướng đến trang đăng nhập
                                        window.location.reload();
                                    },
                                    className: "w-full border border-gray-300 text-gray-700 py-3 rounded-xl font-medium hover:bg-gray-50 transition-colors flex items-center justify-center",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiRefreshCw"], {
                                            className: "mr-2"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/profile/page.tsx",
                                            lineNumber: 388,
                                            columnNumber: 17
                                        }, this),
                                        " Thử lại"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/profile/page.tsx",
                                    lineNumber: 381,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/profile/page.tsx",
                            lineNumber: 373,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/profile/page.tsx",
                    lineNumber: 364,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/profile/page.tsx",
                lineNumber: 363,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/profile/page.tsx",
            lineNumber: 362,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "min-h-screen bg-gradient-to-br from-gray-50 to-white py-12",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",
            children: [
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "bg-red-50 p-4 rounded-lg text-red-600 mb-6",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/src/app/profile/page.tsx",
                    lineNumber: 401,
                    columnNumber: 11
                }, this),
                loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-center items-center min-h-screen",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-yellow-500"
                    }, void 0, false, {
                        fileName: "[project]/src/app/profile/page.tsx",
                        lineNumber: 408,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/profile/page.tsx",
                    lineNumber: 407,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex justify-between items-center mb-6",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-3xl font-bold text-gray-900",
                                children: "Tài khoản của tôi"
                            }, void 0, false, {
                                fileName: "[project]/src/app/profile/page.tsx",
                                lineNumber: 414,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/app/profile/page.tsx",
                            lineNumber: 413,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col lg:flex-row gap-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "lg:w-80 flex-shrink-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-2xl shadow-sm p-6 space-y-6",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "text-center flex flex-col items-center justify-center w-full",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "relative mx-auto mb-4 flex justify-center items-center w-full",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UserAvatar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            name: safeUser.name || '',
                                                            avatar: safeUser.avatar,
                                                            size: 120,
                                                            onChangeAvatar: handleAvatarUpload,
                                                            className: "mx-auto"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                            lineNumber: 424,
                                                            columnNumber: 23
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                        lineNumber: 423,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                        className: "text-xl font-medium text-gray-900 text-center",
                                                        children: safeUser.name || 'Tài khoản'
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                        lineNumber: 432,
                                                        columnNumber: 21
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-sm text-gray-600 mt-1 text-center",
                                                        children: safeUser.email || ''
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                        lineNumber: 433,
                                                        columnNumber: 21
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/profile/page.tsx",
                                                lineNumber: 422,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "pt-4 border-t border-gray-200",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between mb-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                className: "text-base font-medium text-gray-900 flex items-center",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiLock"], {
                                                                        className: "w-5 h-5 mr-2"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                                        lineNumber: 440,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    "Mật khẩu"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/profile/page.tsx",
                                                                lineNumber: 439,
                                                                columnNumber: 23
                                                            }, this),
                                                            !isChangingPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>setIsChangingPassword(true),
                                                                className: "text-sm text-yellow-500 hover:text-yellow-600 font-medium transition-colors",
                                                                children: "Đổi mật khẩu"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/profile/page.tsx",
                                                                lineNumber: 444,
                                                                columnNumber: 25
                                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>{
                                                                    setIsChangingPassword(false);
                                                                    setPasswordError('');
                                                                    setPasswordData({
                                                                        currentPassword: '',
                                                                        newPassword: '',
                                                                        confirmPassword: ''
                                                                    });
                                                                },
                                                                className: "text-sm text-gray-500 hover:text-gray-600 font-medium transition-colors",
                                                                children: "Hủy"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/profile/page.tsx",
                                                                lineNumber: 451,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                        lineNumber: 438,
                                                        columnNumber: 21
                                                    }, this),
                                                    isChangingPassword && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                                        onSubmit: handleChangePassword,
                                                        className: "space-y-4 mt-4",
                                                        children: [
                                                            passwordError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "p-3 bg-red-50 text-red-600 rounded-lg text-sm",
                                                                children: passwordError
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/profile/page.tsx",
                                                                lineNumber: 471,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                        className: "block text-sm font-medium text-gray-700 mb-2",
                                                                        children: "Mật khẩu hiện tại"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                                        lineNumber: 477,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: "password",
                                                                        value: passwordData.currentPassword,
                                                                        onChange: (e)=>setPasswordData({
                                                                                ...passwordData,
                                                                                currentPassword: e.target.value
                                                                            }),
                                                                        className: "w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm",
                                                                        required: true
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                                        lineNumber: 480,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/profile/page.tsx",
                                                                lineNumber: 476,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                        className: "block text-sm font-medium text-gray-700 mb-2",
                                                                        children: "Mật khẩu mới"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                                        lineNumber: 490,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: "password",
                                                                        value: passwordData.newPassword,
                                                                        onChange: (e)=>setPasswordData({
                                                                                ...passwordData,
                                                                                newPassword: e.target.value
                                                                            }),
                                                                        className: "w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm",
                                                                        minLength: 6,
                                                                        required: true
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                                        lineNumber: 493,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/profile/page.tsx",
                                                                lineNumber: 489,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                        className: "block text-sm font-medium text-gray-700 mb-2",
                                                                        children: "Xác nhận mật khẩu mới"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                                        lineNumber: 504,
                                                                        columnNumber: 27
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: "password",
                                                                        value: passwordData.confirmPassword,
                                                                        onChange: (e)=>setPasswordData({
                                                                                ...passwordData,
                                                                                confirmPassword: e.target.value
                                                                            }),
                                                                        className: "w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent text-sm",
                                                                        minLength: 6,
                                                                        required: true
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                                        lineNumber: 507,
                                                                        columnNumber: 27
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/app/profile/page.tsx",
                                                                lineNumber: 503,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "pt-2",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    type: "submit",
                                                                    className: "w-full bg-yellow-500 hover:bg-yellow-600 text-white font-medium py-2 px-3 rounded-lg transition-colors text-sm",
                                                                    children: "Cập nhật mật khẩu"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 518,
                                                                    columnNumber: 27
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/app/profile/page.tsx",
                                                                lineNumber: 517,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                        lineNumber: 469,
                                                        columnNumber: 23
                                                    }, this),
                                                    !isChangingPassword && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-gray-600 text-sm",
                                                        children: "Để đảm bảo an toàn tài khoản, hãy đổi mật khẩu định kỳ."
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/profile/page.tsx",
                                                        lineNumber: 529,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/profile/page.tsx",
                                                lineNumber: 437,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/profile/page.tsx",
                                        lineNumber: 420,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/profile/page.tsx",
                                    lineNumber: 419,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "bg-white rounded-2xl shadow-sm",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "p-6",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center justify-between mb-6",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                            className: "text-2xl font-bold text-gray-900",
                                                            children: "Thông tin cá nhân"
                                                        }, void 0, false, {
                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                            lineNumber: 543,
                                                            columnNumber: 23
                                                        }, this),
                                                        !isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            onClick: ()=>setIsEditing(true),
                                                            className: "flex items-center text-yellow-500 hover:text-yellow-600 transition-colors",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiEdit2"], {
                                                                    className: "w-5 h-5 mr-2"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 551,
                                                                    columnNumber: 27
                                                                }, this),
                                                                "Chỉnh sửa"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                            lineNumber: 547,
                                                            columnNumber: 25
                                                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "flex items-center space-x-3",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: handleCancelEdit,
                                                                    className: "flex items-center space-x-2 text-gray-600 hover:text-gray-700 transition-colors",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiX"], {
                                                                            className: "w-5 h-5"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                                            lineNumber: 560,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        "Hủy"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 556,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                    onClick: handleSaveProfile,
                                                                    className: "flex items-center space-x-2 bg-yellow-500 text-white px-4 py-2 rounded-lg hover:bg-yellow-600 transition-colors",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSave"], {
                                                                            className: "w-5 h-5"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                                            lineNumber: 567,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        "Lưu"
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 563,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                            lineNumber: 555,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                    lineNumber: 542,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "space-y-6",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                                    children: "Họ và tên"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 576,
                                                                    columnNumber: 25
                                                                }, this),
                                                                isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "text",
                                                                    value: editedUser.name || '',
                                                                    onChange: (e)=>setEditedUser({
                                                                            ...editedUser,
                                                                            name: e.target.value
                                                                        }),
                                                                    className: "w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-colors"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 580,
                                                                    columnNumber: 27
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-gray-900",
                                                                    children: safeUser.name || ''
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 587,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                            lineNumber: 575,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                                    children: "Email"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 592,
                                                                    columnNumber: 25
                                                                }, this),
                                                                isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "email",
                                                                    value: editedUser.email || '',
                                                                    onChange: (e)=>setEditedUser({
                                                                            ...editedUser,
                                                                            email: e.target.value
                                                                        }),
                                                                    className: "w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-colors"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 596,
                                                                    columnNumber: 27
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-gray-900",
                                                                    children: safeUser.email || ''
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 603,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                            lineNumber: 591,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                                    children: "Số điện thoại"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 608,
                                                                    columnNumber: 25
                                                                }, this),
                                                                isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "tel",
                                                                    value: editedUser.phone || '',
                                                                    onChange: (e)=>setEditedUser({
                                                                            ...editedUser,
                                                                            phone: e.target.value
                                                                        }),
                                                                    className: "w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-colors"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 612,
                                                                    columnNumber: 27
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-gray-900",
                                                                    children: safeUser.phone || ''
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 619,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                            lineNumber: 607,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                                    children: "Ngày sinh"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 624,
                                                                    columnNumber: 25
                                                                }, this),
                                                                isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                    type: "date",
                                                                    value: editedUser.birthday || '',
                                                                    onChange: (e)=>setEditedUser({
                                                                            ...editedUser,
                                                                            birthday: e.target.value
                                                                        }),
                                                                    className: "w-full px-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-500 focus:border-transparent transition-colors"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 628,
                                                                    columnNumber: 27
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-gray-900",
                                                                    children: safeUser.birthday ? formatDate(safeUser.birthday) : ''
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 635,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                            lineNumber: 623,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                    className: "block text-sm font-medium text-gray-700 mb-2",
                                                                    children: "Giới tính"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 640,
                                                                    columnNumber: 25
                                                                }, this),
                                                                isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                    className: "flex space-x-4",
                                                                    children: [
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "flex items-center",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                    type: "radio",
                                                                                    name: "gender",
                                                                                    value: "male",
                                                                                    checked: editedUser.gender === 'male',
                                                                                    onChange: (e)=>setEditedUser({
                                                                                            ...editedUser,
                                                                                            gender: e.target.value
                                                                                        }),
                                                                                    className: "w-4 h-4 text-yellow-500 border-gray-300 focus:ring-yellow-500"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                                    lineNumber: 646,
                                                                                    columnNumber: 31
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: "ml-2 text-gray-700",
                                                                                    children: "Nam"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                                    lineNumber: 654,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                                            lineNumber: 645,
                                                                            columnNumber: 29
                                                                        }, this),
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                            className: "flex items-center",
                                                                            children: [
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                                    type: "radio",
                                                                                    name: "gender",
                                                                                    value: "female",
                                                                                    checked: editedUser.gender === 'female',
                                                                                    onChange: (e)=>setEditedUser({
                                                                                            ...editedUser,
                                                                                            gender: e.target.value
                                                                                        }),
                                                                                    className: "w-4 h-4 text-yellow-500 border-gray-300 focus:ring-yellow-500"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                                    lineNumber: 657,
                                                                                    columnNumber: 31
                                                                                }, this),
                                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                                    className: "ml-2 text-gray-700",
                                                                                    children: "Nữ"
                                                                                }, void 0, false, {
                                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                                    lineNumber: 665,
                                                                                    columnNumber: 31
                                                                                }, this)
                                                                            ]
                                                                        }, void 0, true, {
                                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                                            lineNumber: 656,
                                                                            columnNumber: 29
                                                                        }, this)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 644,
                                                                    columnNumber: 27
                                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                    className: "text-gray-900",
                                                                    children: safeUser.gender === 'male' ? 'Nam' : 'Nữ'
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                                    lineNumber: 669,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/src/app/profile/page.tsx",
                                                            lineNumber: 639,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/src/app/profile/page.tsx",
                                                    lineNumber: 574,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/profile/page.tsx",
                                            lineNumber: 541,
                                            columnNumber: 19
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/profile/page.tsx",
                                        lineNumber: 539,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/profile/page.tsx",
                                    lineNumber: 538,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/profile/page.tsx",
                            lineNumber: 417,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/profile/page.tsx",
            lineNumber: 399,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/profile/page.tsx",
        lineNumber: 398,
        columnNumber: 5
    }, this);
}
_s(ProfilePage, "VjSupb3+b1SEVbwRs/8hqdCt0hM=");
_c = ProfilePage;
var _c;
__turbopack_context__.k.register(_c, "ProfilePage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_b7cf3cfe._.js.map